﻿$(function () {

	var sideNavContainer = $('#mainNav');

	// if there is a side nav on the page
	if (sideNavContainer.length !== 0) {

		// get the children
		var pages = $('#mainNav > li');

		var buildNavStructure = function (items, depth) {
			depth = depth || 0;
			var out = [];

			$.each(items, function (index, item) {
				item = $(item);

				var obj = {
					title: item.find('a').first().text(),
					url: item.find('a').first().attr('href'),
					selected: item.hasClass('current'),
					children: []
				};

				// check if there is a subnav
				var childList = item.first().children('ul');
				if (childList.length !== 0) {

					var children = childList.children('li');

					if (children.length) {
						obj.children = buildNavStructure(children, depth + 1);
					}

				}

				out.push(obj);

			});

			return out;
		};

		var navStructure = buildNavStructure(pages);



		var selectBox = $('<select>');

		var buildSelectNav = function (structure, depth) {
			depth = depth || 0;

			// determine the indent prefix based on how deep we are
			var prefix = Array(depth + 1).join('─');
			prefix = prefix.length !== 0 ? prefix + ' ' : prefix;

			$.each(structure, function (index, item) {
				var option = $('<option>').attr('value', item.url).text(prefix + item.title);

				if (item.selected) option.attr('selected', 'selected');

				if (item.children.length !== 0) {
					var parentOption = $('<option>').attr('value', item.url).text(prefix + item.title).appendTo(selectBox);
					if (item.selected) parentOption.attr('selected', 'selected');
					buildSelectNav(item.children, depth + 1);
				} else {
					option.appendTo(selectBox);
				}

			});

			return selectBox;
		};

		// build the nav with the extracted structure
		buildSelectNav(navStructure);

		selectBox.on('change', function () {
			window.location.href = $(this).val();
		});

		var selectNavContainer = $('<div>').addClass('hide-for-medium-down select-subnav').html(selectBox);

		$('#row-2').prepend(selectNavContainer);

	}

});


$(document).ready(function() {
	function isIE(){

		if ($.browser.msie) {

			var version = parseInt($.browser.version, 10);

			$('html').addClass('ie ie' + version);

			if (version === 6) {

				if (document.cookie.indexOf("ie6check") >= 0) {
				  //do nothing
				} else {
					var date = new Date();
					var m = 10000;
					date.setTime(date.getTime() + (m * 60 * 1000));
					document.cookie = "ie6check=yes; expires=" + date.toGMTString();
					var content = "<div id='ie6-modal' style='position:absolute; top:0; left:0; width:100%!important; height:100%!important; z-index:999999; background:rgb(0,0,0); background: transparent\9; background:rgba(0,0,0,0.8); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#cc000000,endColorstr=#cc000000); zoom: 1;'><div id='ie6-content' style='background:#fff; position:absolute; top:10%; left:25%; width:50%; padding:40px; text-align:center'><p>We've noticed that you are using an old version of Internet Explorer, which is something we no longer support. To be able to access your Online Banking, you will need to update your browser to the latest version of Internet Explorer by visiting <a href='http://www.microsoft.com/ie' target='_blank'>www.microsoft.com/ie</a>.</p><p>Alternatively, you can use one of the following supported browsers:</p><ul><li><a href='http://www.google.com/chrome/' target='_blank'>Chrome</a></li><li><a href='https://www.mozilla.org/en-GB/firefox/new/' target='_blank'>Firefox</a></li></ul><span id='ie6-close' style='position: absolute; top: 0; right: 10px; width: 40px; height: 40px; line-height: 40px; display: block; cursor: pointer;'>close</span></div></div>";

					$('html, body').attr('style','position:relative; height:100%!important; width:100%!important; overflow:hidden; z-index:1;');
					$('#ls-canvas').attr('style','position: absolute; top: 0; left: 50%; margin-left: -490px; z-index: 1;');
					setTimeout(function(){
						  $('body').append(content);
						//$(content).appendTo( $( "body" ) );
					},50);
					$('#ie6-close').live('click', function(){
						$('#ie6-modal').remove();
						$('html, body, #ls-canvas').removeAttr('style');
					});
				}
			}

			if (version === 8){
				$('.hub-grid .span5:nth-child(odd), .image-box:nth-child(even) .bkg-wrapper, .image-box:nth-child(even) .textbox, .triple-list > li:nth-child(5n-1)').addClass('iechild');
			}

		}
	}

	function isMobile(){
		var check = false;
		(function(a,b){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true})(navigator.userAgent||navigator.vendor||window.opera);
		return check;
	}

	function addMobileClass(){
		if ( isMobile() ){
			$('body,html').addClass('mobile');
		}else{
			$('body,html').addClass('desktop');
		}
	}

	isIE();
	addMobileClass();

	// prevent the site being embedded in iframes
	try{
		if (window.self.location.host !== window.top.location.host) {
			var sitehost = window.location.host;
			if((sitehost.indexOf("co-operativebank") != -1) || (sitehost.indexOf("smile") != -1)){
				if (window.self !== window.top) {
					window.top.location.href = window.location.href;
				}
			}
		}
	}catch(e){
		window.top.location.href = window.location.href;
	}


	//check to see if the channel hub and sub_nav have been set in the page
	//if they are set then set display properties

	try{
		if((hub != undefined) && (hub.length > 0)) {
			$("#nav_"+hub).addClass("active");


		}
		if((sub_nav_1 != undefined) && (sub_nav_1.length > 0)) {
			$("#subnav_"+sub_nav_1).addClass("activeSub");
		}
		if((sub_nav_2 != undefined) && (sub_nav_2.length > 0)) {
			$("#subnav_"+sub_nav_2).addClass("active");
		}
		if((sub_nav_3 != undefined) && (sub_nav_3.length > 0)) {
			$("#subnav_"+sub_nav_3).addClass("active");
		}
	}catch(e){}

	//Hide any toggled content
	$('.toggle').hide();


	//Set Navigation active states
	var path = window.location.pathname,
	pathArray = path.split( '../../index.html' ),
	section = pathArray[1],
	subSection = pathArray[2];
	//Set Tabs
	if(typeof section != 'undefined'){
		if ($("#nav-left li a[href*='"+section+"']").length ){
			$("#nav-left li a[href*='"+section+"']").addClass('active');
		}else{
			$("#nav-left li a[href='/']").addClass('active');
		}
	}else{
		$("#nav-left li a[href='/']").addClass('active');
	}

	//Set Active Navigation Link
	if (section.length > 1){
		var activeURL;
		if (section == "business"|| section == "corporate" || section == "offshorebanking"){
			activeURL = section+'/'+subSection;
		}else{
			activeURL = section;
		}
		$("#nav > li > a[href^='/"+activeURL+"']").parent('li').addClass('activeSub');
	}

	/*MegaNav dropDowns*/
	function showMeganav(elem){
		$('#nav > li').removeClass('active activeSub');
		$(elem).addClass('active activeSub');
	}

	function hideMeganav(){
		$('#nav > li').removeClass('active activeSub');
	}

	function showMegaSubnav(elem){
		$('.megaNav dl').removeClass('active');
		$(elem).addClass('active');
	}

	function hideMegaSubnav(){
		$('.megaNav dl').removeClass('active');
	}

	$('.mobile a.navDropdown, html.nav-open a.navDropdown').live('click',function(e){
		e.preventDefault();
		var activeItem  = $(this).parent('li');
		($(activeItem).hasClass("active")) ? hideMeganav() : showMeganav(activeItem);
	});
	$('.megaNav dt').live('click',function(e){
		var activeItem  = $(this).parent('dl');
		($(activeItem).hasClass("active")) ? hideMegaSubnav() : showMegaSubnav(activeItem);
		
	});
	
	$('#nav a.navDropdown.nolink').click(function (e) {
		e.preventDefault();
		/* prevent top level links from linking when empty */
	});

	$(document).click(function (e) {
		var container = $("#nav");
		if (!container.is(e.target)  && container.has(e.target).length === 0) {
			hideMeganav();
		}
	});
	
	$('.mobile #btnLogin').click(function (e) {
		e.preventDefault();
		$(this).parent('ul').toggleClass('active');
	});
	
	$('.desktop #btnLogin').click(function (e) {
		e.preventDefault();
		showSplashByName('splash1',function(){location.href='http://www.smile.co.uk/utilities/account-log-in'})
	});

	$(document).click(function (e) {
		var container = $(".mobile #btnLogin");
		if (!container.is(e.target)  && container.has(e.target).length === 0) {
			$('#btnLogin').parent('ul').removeClass('active');
		}
	});
	
	/*Disable :tel links on desktop*/
	$('.desktop a.tel').on('click', function(e){
		e.preventDefault();
		return false;
	});

});



/* Check if mobile device */
var ismobile = false;
var redirectagent = navigator.userAgent.toLowerCase();
var redirect_devices = ['iphone', 'android', 'blackberry'];

for (var i in redirect_devices) {
	if (redirectagent.indexOf(redirect_devices[i]) != -1) {
		// allow android phone but not tablets
		if(i == "android"){
			if(redirectagent.indexOf("mobile") != -1){
				var ismobile = true;
				var thisdevice = i;
			}
		// allow iphones and blackberry
		} else{
			var ismobile = true;
			var thisdevice = i;
		}
	}
}



/************************************************************
*   Functions for meta FAQ                                  *
************************************************************/

function openWin(textIn, kbArea){
var  nlpq = textIn.value;
var  kb = kbArea.value;
	var mfWin=window.open("http://ask.co-operativebank.co.uk/templates/co-operativebank/seo/resultsPage?nlpq=" + escape(nlpq) + "&amp;kb=" + kb,mfWin,"screenX=10,screenY=10,left=10,top=10,width=600,height=750,resizable");
	mfWin.focus();
}

/************************************************************
*   END Functions for meta FAQ                              *
************************************************************/


/************************************************************
*   Functions for expanding content                         *
************************************************************/
	$(function() {
		if ($('.toggler').length > 0 ){
			$(function() {
				$('.toggler').click( function() {
					  var target = this.id + '_content';
					  var imgtarget = this.id + '_img';

			 $('#' + target).slideToggle(function(){
					 if ($('#' + target).is(':visible')) {
						$('#' + imgtarget).attr("src","../../assets/images/common/FAQ/collapse.gif");
					 }

				  else {
						$('#' + imgtarget).attr("src","../../assets/images/common/FAQ/expand.gif");
					 }
			  });

			});

		  $('.showall').click(function() {
			$('.toggle').show('slow');
			$(".toggleimg").attr("src","../../assets/images/common/FAQ/collapse.gif");
		  });


		  $('.hideall').click(function() {
			$('.toggle').hide('slow');
			$(".toggleimg").attr("src","../../assets/images/common/FAQ/expand.gif");
		  });
		 });
		}

	});

/************************************************************
*   END Functions for expanding content                     *
************************************************************/

/************************************************************
*   Functions for tabbed sliding content                    *
************************************************************/
$(function() {

	if ($('.ui-tabs-panel').length > 0 ){

		var $tabs = $('#tabs').tabs();

		$(".ui-tabs-panel").each(function(i){

		  var totalSize = $(".ui-tabs-panel").size() - 1;

		  if (i != totalSize) {
			  next = i + 2;
			  $(this).append("<a href='#' class='next-tab mover' rel='" + next + "'>Next Page &#187;</a>");
			  $('.toggle').hide();
		  }

		  if (i != 0) {
			  prev = i;
			  $(this).append("<a href='#' class='prev-tab mover' rel='" + prev + "'>&#171; Prev Page</a>");
			  $('.toggle').hide();
		  }

		});

		$('.next-tab, .prev-tab').click(function() {
			   $tabs.tabs('select', $(this).attr("rel"));
			   return false;
		   });

		  }

});

/************************************************************
*   END Functions for tabbed sliding content                *
************************************************************/


/************************************************************
*   Settings for accordion                                  *
************************************************************/
$(function() {

	 if ($('.accordionContent').length > 0 ){

		//ACCORDION BUTTON ACTION (ON CLICK DO THE FOLLOWING)
		$('.accordionButton').click(function() {
			//var buttonid = $(this).attr("id");
			//REMOVE THE ON CLASS FROM ALL BUTTONS
			$('.accordionButton').removeClass('on');

			//NO MATTER WHAT WE CLOSE ALL OPEN SLIDES
			$('.accordionContent').slideUp('normal');
			$('.accordionContentOn').slideUp('normal');

			//IF THE NEXT SLIDE WASN'T OPEN THEN OPEN IT
			if($(this).next().is(':hidden') == true) {

				//ADD THE ON CLASS TO THE BUTTON
				$(this).addClass('on');
				$(this).removeAttr('id');
				//$(this).attr('id', buttonid);
				//alert(buttonid);
				//OPEN THE SLIDE
				$(this).next().slideDown('normal');
			 }

		 });
	 };
/*	//ADDS THE .OVER CLASS FROM THE STYLESHEET ON MOUSEOVER
	$('.accordionButton').mouseover(function() {
		$(this).addClass('over');

	//ON MOUSEOUT REMOVE THE OVER CLASS
	}).mouseout(function() {
		$(this).removeClass('over');
	});

	/********************************************************************************************************************
	CLOSES ALL S ON PAGE LOAD
	********************************************************************************************************************/
 	$('.accordionContent').hide();
});

/************************************************************
* END Settings for accordion                                *
************************************************************/



/************************************************************
*   Settings for fancybox used for the jquery lightbox      *
************************************************************/


// $(function() {

	// if ($('.fancybox-effect').length > 0 ){

	// $('.fancybox').fancybox();

	// Set custom style, close if clicked, change title type and overlay color
	// $(".fancybox-effect").fancybox({
	// 	wrapCSS    : 'fancybox-custom',
	// 	closeClick : true,
	// 	speedIn : '2500',
	// 	speedOut : '2500',
	// 	helpers : {
	// 		title : 'none',
	// 		overlay : {
	// 			css : {
	// 				'background-color' : '#eee'
	// 			}
	// 		}
	// 	}
	// });
	// }
// });

/************************************************************
*   END settings for fancybox                               *
************************************************************/



/************************************************************
*   Settings for featurebox                                 *
************************************************************/
$(function() {

	if ($('#featureList').length > 0 ){
			$.featureList(
				$("#tabs li a"),
				$("#output li"), {
					start_item	:	0
				}
			)};
		});
/************************************************************
*   END Settings for featurebox                             *
************************************************************/

/************************************************************
*   Settings for homepage slider box                        *
************************************************************/
$(function(){

if ($('#slider1').length > 0 ){

	$('#slider1').anythingSlider({
		theme           : 'metallic',
		buildStartStop  : false,
		pauseOnHover    : true,
		mode            : 'h',
		autoPlay        : true,
		hashTags        : false,
		delay           : 4000,
		buildArrows     : false
	 });
	};
});

/************************************************************
*   END Settings for homepage slider box                   *
************************************************************/

/**********************************************************/
/* Start - Cookie Banner Code
/**********************************************************/

$(document).ready(function(){

	readEuCookies();

	if(typeof eucookieName == 'undefined'){
    	$("#noticePanel").slideToggle("fast");
		euCookies("cookienote");
	}

	// This code is used if there is check box to then show the close button on banner
	/*
	$("#cookiebox").click(function(){
		// If checked
		if ($("#cookiebox").is(":checked")){
			$("#closeNotice").slideToggle("slow");
		}
		else{
			$("#closeNotice").slideToggle("slow");
		}
	});
	*/

	// This is used to close the banner
	/*
	$("#noticePanel #closeNoticeBut").click(function(){
		$(this).parents("#noticePanel").hide("slow");
	});
	*/

	// slide down more info (mobile panel)
	$("#noticePanel #noticeCopy span").click(function(){
		$(this).hide();
		$("#noticePanel div.noticeReveal").slideDown("slow");
	});

	// hide
	$("#noticePanel div.noticeButton").click(function(){
		$(this).parents("#noticePanel").hide();
	});

});



// Set Cookie regarding euCookies - This is activated when user clicks on button in banner

function euCookies(euCook){

expireCookieDate = new Date;
expireCookieDate.setMonth(expireCookieDate.getMonth()+6);

document.cookie = "cookieLaw=" + escape(euCook) + ";expires=" + expireCookieDate.toGMTString() + ";path=/";

}

// Get Cookie information for EU Cookies

function readEuCookies() {

//reading and splitting the whole cookie
var whole_cookie = unescape(document.cookie);
var eu_cookie = whole_cookie.split(";");

//sorting cookies
for (i = 0; i < eu_cookie.length; i++){
if (eu_cookie[i].indexOf("cookieLaw=") > -1)

	{
	var eu_cookie_data = eu_cookie[i];

	}

}

//splitting data and assigning final display variable
if (eu_cookie_data) {
var eucookie_split = eu_cookie_data.split("=");
eucookieName = eucookie_split[1];

}
	//alert (eucookieName);


}

/**********************************************************/
/* End - Cookie Banner Code
/**********************************************************/

/*******************************************************************/
/* Start - JS for dynamic buttons for MSN codes on landing pages
/*******************************************************************/
function checkMediaCode(url)
{
		loc = document.location.href;

		mediaCodeFind=loc.indexOf("&") + 1; //count characters required for server address - everything after &

		getText=loc.substring(mediaCodeFind); // get address after &


		if(mediaCodeFind > 1)
		{

		textSplit = getText.split("=");

		var mediastring = textSplit[0];
		if (mediastring == "media")
			{

			//result = url + textSplit[1];
			//break;

			url = url + textSplit[1];

			//alert(url);

			//newAddress= loc;
			//window.location.href=url;
			}


		}
	return url;

}


/*******************************************************************/
/* End - JS for dynamic buttons for MSN codes on landing pages
/*******************************************************************/

/**********************************************************/
/* Ask a question - Tranversal
/**********************************************************/


function openWin(textIn, kbArea){
var  nlpq = textIn.value;
var  kb = kbArea.value;
	var mfWin=window.open("http://ask.co-operativebank.co.uk/templates/co-operativebank/seo/resultsPage?nlpq=" + escape(nlpq) + "&amp;kb=" + kb,mfWin,"screenX=10,screenY=10,left=10,top=10,width=600,height=750,resizable");
	mfWin.focus();
}


/**********************************************************/
/* End - Ask a question - Tranversal
/**********************************************************/


/**********************************************************/
/* Start - Rapport for PIBS
/**********************************************************/


(function(){
    var splashTarget = null,
        splashMap = {
          "splash1": "23231"

        };

    for(var k in splashMap){
        var snippetID = splashMap[k],
            host = 'www.splash-screen.net',
            sn = document.createElement('script');
        sn.setAttribute('async', true);
        sn.setAttribute('type', 'text/javascript');
        sn.setAttribute('src', (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//' + host + '/' + snippetID + '/' + 'splash.js');
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(sn, s);
    }

	window.showSplashByName = function(name,func){


		// currently disabled
		/*
		if(ismobile == true){
			window.location.href = "/mobile/mobile-entrance";
			return false;
		}
		*/


		/*
		// cookie based version
		if(ismobile == true){
			var ShowMobileBankingSplash = $.cookie("ShowMobileBankingSplash");
			var cookiecount = 0;
			if((ShowMobileBankingSplash <= 2)||(ShowMobileBankingSplash == undefined)){
				window.location.href = "/mobile/mobile-entrance";
				cookiecount = cookiecount + 1;
				$.cookie("ShowMobileBankingSplash", cookiecount, {path:'/',expires:30});
				return false;
			}
		}
		*/

		/* if not mobile then show splash as normal */
		//else {

			splashTarget = func;
			if(splashMap[name] && window["splashScreen_"+splashMap[name]] != undefined){
				try{
					window["splashScreen_"+splashMap[name]].apply(this, []);
				}
				catch(e){
					splashClosed('none');
				}
			}
			else {
				splashClosed('none');
			}
			return false;

		//}

    }
    window.splashClosed = function (source){
     if(splashTarget != null){
       splashTarget(source);
     }
    };
  })();


/**********************************************************/
/* End - Rapport for PIBS
/**********************************************************/

/**********************************************************/
/* Start - Redirect function based on cookies
/**********************************************************/

window.onload = function(){

		/* Start - Bondholder Prospectus*/

	$('.agreeButton').on('click', function(event){
		event.preventDefault();
		$.cookie("prospectusElectronicGatepost", "true", {path:'/',expires:120});
		var redirectURL = $.cookie("prospectusCurrentPageURL");
		if(redirectURL === undefined)
			window.location = "../../investorrelations/index";
		else
			window.location = redirectURL;
	}); /* End - Bondholder Prospectus */


		/* Start - Offshore Imp Info Check*/

	$('.impInfoCheckButton').on('click', function(event){
		event.preventDefault();
		$.cookie("offshoreElectronicGatepost", "true", {path:'/',expires:120});
		var redirect2URL = $.cookie("offshoreCurrentPageURL");
		if(redirect2URL === undefined)
			window.location = "../../offshorebanking/index";
		else
			window.location = redirect2URL;
	}); /* End - Offshore Imp Info Check*/

	/* Start - Debt Investor Disclaimer*/

	$('.agreeDebtInvestDisclaimer').on('click', function(event){
		event.preventDefault();
		$.cookie("DebtInvestDisclaimerGatepost", "true", {path:'/',expires:120});
		var redirectURL = $.cookie("DebtInvestCurrentPageURL");
		if(redirectURL === undefined)
			window.location = "../../investorrelations/debtinvestors/index";
		else
			window.location = redirectURL;
	}); /* End - Debt Investor Disclaimer */



	// gateway must be accepted each time user attempts to download pdf (see below for earlier version)
	$('.approvalPDF').click(function(event) {
		event.preventDefault();
		// save url
		if($(this).attr("title") != undefined){
			// build url
			var currentPageURL = $(this).attr("title");
			currentPageURL = currentPageURL.toLowerCase();
			currentPageURL = $.trim(currentPageURL);
			currentPageURL = "/assets/pdf/bank/news/" + currentPageURL.replace(/ /g, "-") + ".pdf";
			// set cookie
			$.cookie("reportCapUpdateFileURL", currentPageURL, {path:'/'});
			// go to gatepost
			window.location = "../../news/2014/disclaimer/electronic-gatepost";
		}
	});

	/*
	$('.reportCapUpdate').on('click', function(event){
		event.preventDefault();
		// save url
		var currentPageURL = $(this).attr("href");
		$.cookie("reportCapUpdatePageURL", currentPageURL, {path:'/'});
		// got to gatepost
		window.location = "/news/2014/disclaimer/electronic-gatepost";
	});
	*/

	$('.agreeRepCapUpdate').on('click', function(event){
		// get url
		var redirectURL = $.cookie("reportCapUpdateFileURL");
		//check it aint blank
		if(redirectURL === undefined){
			window.location = "news/2014";
		}
		else{
			// if not then go there
			window.location = redirectURL;
		}
	});

/*
	// When gateway accepted cookie expires after 3 months
	// removed as per request from Treasury and Investors relations team

	if($.cookie("ReportCapUpdateGatepost") === undefined)
	event.preventDefault();
	$.cookie("ReportCapUpdateGatepost", "false", {path:'/',expires:120});

	if($.cookie("ReportCapUpdateGatepost") === "false"){
		var currentPageURL = $(this).attr("href")
		//alert (currentPageURL);
		$.cookie("reportCapUpdatePageURL", currentPageURL, {path:'/'});
		window.location = "/news/2014/disclaimer/electronic-gatepost";
	}
	//else
	//window.location.href;

	}); //End - New March 2014 For Reporting and Captial Update


	// Start - Reporting and Captial Update Disclaimer

	$('.agreeRepCapUpdate').on('click', function(event){
		event.preventDefault();
		$.cookie("ReportCapUpdateGatepost", "true", {path:'/',expires:120});
		var redirectURL = $.cookie("reportCapUpdatePageURL");
		if(redirectURL === undefined)
			window.location = "news/2014";
		else
			window.location = redirectURL;
	}); // End - Reporting and Captial Update Disclaimer

*/





}; //end window onload

/**********************************************************/
/* End - Redirect function based on cookies
/**********************************************************/


/**********************************************************/
/* Start Caroufredsel Carousel
/**********************************************************/


/*	CarouFredSel: a circular, responsive jQuery carousel.
	Configuration created by the "Configuration Robot"
	at caroufredsel.dev7studios.com
*/


$(document).ready(function() {


					if ($('#carousel').length > 0 ){

						$("#carousel").carouFredSel({
						width: 942,
						height: 430,
						circular: true,
						infinite: true,
						items: {
							/*visible: 1,
							width: 954,
							height: 260,*/
							/*start: "random"*/
						},
						scroll : {
						items			: 1,
						fx				: "fade",
						easing			: "linear",
						duration		: 2000,
						pauseOnHover	: true
						},
						prev: "#prev_btn",
						next: "#next_btn",
						pagination: {
							 container : "#pager_container",
							 fx		   : "fade",
							 easing	   : "linear",
							 duration  : 2000

						},
						direction	: "left",
						auto : {

							fx			: "fade",
							easing		: "linear",
							duration	: 2000,
							timeoutDuration: 4000,
							pauseOnHover: true
						},
						swipe: {
						onTouch			: true,
						onMouse			: true

						}

					});
				};

			});

/**********************************************************/
/* End Caroufredsel Carousel
/**********************************************************/


$(document).ready(function() {

	/* ----- Fire Trusteer ----- */
	$('a.splashmsg').live('click',function(e){
		e.preventDefault();

		if($(this).attr("href")){
			var thishref = $(this).attr("href");
		}else{
			var thishref = "https://personal.co-operativebank.co.uk/CBIBSWeb/start.do";
		}

		showSplashByName('splash1',function(){location.href=thishref})
	});

	$('.splashmsg-nav').live('click',function(e){
		e.preventDefault();
		if ($('.nav-open').length){
			$('#nav-login').toggleClass('active');
			return false;
		}else{

			if($(this).attr("href")){
				var thishref = $(this).attr("href");
			}else{
				var thishref = "https://personal.co-operativebank.co.uk/CBIBSWeb/start.do";
			}

			showSplashByName('splash1',function(){location.href=thishref})
		}
	});

	$('a.splashMsg-register').live('click',function(e){
		e.preventDefault();
		showSplashByName('splash1',function(){location.href='https://personal.co-operativebank.co.uk/CBIBSWeb/registration.do'})
	});

	/* ----- add responsive menus ----- */
	/* copy nav elements to mobile nav */
	$("#section-nav ul#nav-right").clone().appendTo("#navigation");
	$("#navitem-login a").first().clone().appendTo("#nav-iconlogin");

	/*if($("#navigation #nav li.activeSub").length >= 1){
		$("ul#mainNav ul").clone().appendTo("#navigation #nav li.activeSub");
	}
	else{
		$("ul#mainNav").clone().appendTo("#navigation");
	}*/

	$("#navigation ul#nav-right").addClass("responsiveNav");
	//$("#navigation ul#mainNav").addClass("responsiveNav");

	/* remove attributes from login dropdown on mobiles */
	if(ismobile){
		$("#navigation #nav-login #navitem-login a").first().removeAttr("onclick");
		$("#navigation #nav-login #navitem-login a").first().removeAttr("href");
	}

	/* Responsive Nav */
	$('#nav-icon').live('click', function(e){
		e.preventDefault();
		e.stopPropagation();
		if(!$("html").hasClass("nav-open")){
			setTimeout(function(){
				$('html').addClass('nav-open');
				},50);
		}else{
			setTimeout(function(){
				$('html').removeClass('nav-open');
			},50);
		}
	});

	/* close nav when click unless login dropdown */
	/*$(document).live( "click", "html.nav-open", function(e) {
		if(e.target != $('#navigation') || {
			$('html').removeClass('nav-open');
		}
	});*/
	$(document).live( "click", "html.nav-open", function(e) {
		var container = $("#navigation");
		if (!container.is(e.target)  && container.has(e.target).length === 0) {
			$('html').removeClass('nav-open');
		}
	});


	/* close nav on orientation change */
	if(window.DeviceOrientationEvent){
		var previousOrientation = window.orientation;
		var checkOrientation = function(){
			if(window.orientation !== previousOrientation){
				previousOrientation = window.orientation;
				$('html').removeClass('nav-open');
			}
		};

		window.addEventListener("resize", checkOrientation, false);
		window.addEventListener("orientationchange", checkOrientation, false);
	}

	/* error messages when flash is not supported */
	if($('embed').length ){
		var hasFlash = false;
		try {
			var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
			if (fo) {
				hasFlash = true;
			}
		} catch (e) {
			if (navigator.mimeTypes && navigator.mimeTypes['application/x-shockwave-flash'] != undefined && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
				hasFlash = true;
			} else {
				$('embed').replaceWith('<div class="noflash"><p>Sorry - Your device does not support Adobe Flash, which is required to view the content on this page</p></div>');
			}
		}
	}

	/* set eDR timer when login clicked to prevent survey */
	$('ul#nav-login a, span#nav-iconlogin a').click(function() {
		try {
			EDRSurvey.setDateTimeCookie(5 * 60);
		}
		catch (e){}
	});

});


/*!
	Colorbox 1.5.14
	license: MIT
	http://www.jacklmoore.com/colorbox
*/
(function(t,e,i){function n(i,n,o){var r=e.createElement(i);return n&&(r.id=Z+n),o&&(r.style.cssText=o),t(r)}function o(){return i.innerHeight?i.innerHeight:t(i).height()}function r(e,i){i!==Object(i)&&(i={}),this.cache={},this.el=e,this.value=function(e){var n;return void 0===this.cache[e]&&(n=t(this.el).attr("data-cbox-"+e),void 0!==n?this.cache[e]=n:void 0!==i[e]?this.cache[e]=i[e]:void 0!==X[e]&&(this.cache[e]=X[e])),this.cache[e]},this.get=function(e){var i=this.value(e);return t.isFunction(i)?i.call(this.el,this):i}}function h(t){var e=W.length,i=(z+t)%e;return 0>i?e+i:i}function a(t,e){return Math.round((/%/.test(t)?("x"===e?E.width():o())/100:1)*parseInt(t,10))}function s(t,e){return t.get("photo")||t.get("photoRegex").test(e)}function l(t,e){return t.get("retinaUrl")&&i.devicePixelRatio>1?e.replace(t.get("photoRegex"),t.get("retinaSuffix")):e}function d(t){"contains"in y[0]&&!y[0].contains(t.target)&&t.target!==v[0]&&(t.stopPropagation(),y.focus())}function c(t){c.str!==t&&(y.add(v).removeClass(c.str).addClass(t),c.str=t)}function g(e){z=0,e&&e!==!1&&"nofollow"!==e?(W=t("."+te).filter(function(){var i=t.data(this,Y),n=new r(this,i);return n.get("rel")===e}),z=W.index(_.el),-1===z&&(W=W.add(_.el),z=W.length-1)):W=t(_.el)}function u(i){t(e).trigger(i),ae.triggerHandler(i)}function f(i){var o;if(!G){if(o=t(i).data(Y),_=new r(i,o),g(_.get("rel")),!$){$=q=!0,c(_.get("className")),y.css({visibility:"hidden",display:"block",opacity:""}),L=n(se,"LoadedContent","width:0; height:0; overflow:hidden; visibility:hidden"),b.css({width:"",height:""}).append(L),D=T.height()+k.height()+b.outerHeight(!0)-b.height(),j=C.width()+H.width()+b.outerWidth(!0)-b.width(),A=L.outerHeight(!0),N=L.outerWidth(!0);var h=a(_.get("initialWidth"),"x"),s=a(_.get("initialHeight"),"y"),l=_.get("maxWidth"),f=_.get("maxHeight");_.w=(l!==!1?Math.min(h,a(l,"x")):h)-N-j,_.h=(f!==!1?Math.min(s,a(f,"y")):s)-A-D,L.css({width:"",height:_.h}),J.position(),u(ee),_.get("onOpen"),O.add(F).hide(),y.focus(),_.get("trapFocus")&&e.addEventListener&&(e.addEventListener("focus",d,!0),ae.one(re,function(){e.removeEventListener("focus",d,!0)})),_.get("returnFocus")&&ae.one(re,function(){t(_.el).focus()})}var p=parseFloat(_.get("opacity"));v.css({opacity:p===p?p:"",cursor:_.get("overlayClose")?"pointer":"",visibility:"visible"}).show(),_.get("closeButton")?B.html(_.get("close")).appendTo(b):B.appendTo("<div/>"),w()}}function p(){y||(V=!1,E=t(i),y=n(se).attr({id:Y,"class":t.support.opacity===!1?Z+"IE":"",role:"dialog",tabindex:"-1"}).hide(),v=n(se,"Overlay").hide(),S=t([n(se,"LoadingOverlay")[0],n(se,"LoadingGraphic")[0]]),x=n(se,"Wrapper"),b=n(se,"Content").append(F=n(se,"Title"),I=n(se,"Current"),P=t('<button type="button"/>').attr({id:Z+"Previous"}),K=t('<button type="button"/>').attr({id:Z+"Next"}),R=n("button","Slideshow"),S),B=t('<button type="button"/>').attr({id:Z+"Close"}),x.append(n(se).append(n(se,"TopLeft"),T=n(se,"TopCenter"),n(se,"TopRight")),n(se,!1,"clear:left").append(C=n(se,"MiddleLeft"),b,H=n(se,"MiddleRight")),n(se,!1,"clear:left").append(n(se,"BottomLeft"),k=n(se,"BottomCenter"),n(se,"BottomRight"))).find("div div").css({"float":"left"}),M=n(se,!1,"position:absolute; width:9999px; visibility:hidden; display:none; max-width:none;"),O=K.add(P).add(I).add(R)),e.body&&!y.parent().length&&t(e.body).append(v,y.append(x,M))}function m(){function i(t){t.which>1||t.shiftKey||t.altKey||t.metaKey||t.ctrlKey||(t.preventDefault(),f(this))}return y?(V||(V=!0,K.click(function(){J.next()}),P.click(function(){J.prev()}),B.click(function(){J.close()}),v.click(function(){_.get("overlayClose")&&J.close()}),t(e).bind("keydown."+Z,function(t){var e=t.keyCode;$&&_.get("escKey")&&27===e&&(t.preventDefault(),J.close()),$&&_.get("arrowKey")&&W[1]&&!t.altKey&&(37===e?(t.preventDefault(),P.click()):39===e&&(t.preventDefault(),K.click()))}),t.isFunction(t.fn.on)?t(e).on("click."+Z,"."+te,i):t("."+te).live("click."+Z,i)),!0):!1}function w(){var e,o,r,h=J.prep,d=++le;if(q=!0,U=!1,u(he),u(ie),_.get("onLoad"),_.h=_.get("height")?a(_.get("height"),"y")-A-D:_.get("innerHeight")&&a(_.get("innerHeight"),"y"),_.w=_.get("width")?a(_.get("width"),"x")-N-j:_.get("innerWidth")&&a(_.get("innerWidth"),"x"),_.mw=_.w,_.mh=_.h,_.get("maxWidth")&&(_.mw=a(_.get("maxWidth"),"x")-N-j,_.mw=_.w&&_.w<_.mw?_.w:_.mw),_.get("maxHeight")&&(_.mh=a(_.get("maxHeight"),"y")-A-D,_.mh=_.h&&_.h<_.mh?_.h:_.mh),e=_.get("href"),Q=setTimeout(function(){S.show()},100),_.get("inline")){var c=t(e);r=t("<div>").hide().insertBefore(c),ae.one(he,function(){r.replaceWith(c)}),h(c)}else _.get("iframe")?h(" "):_.get("html")?h(_.get("html")):s(_,e)?(e=l(_,e),U=new Image,t(U).addClass(Z+"Photo").bind("error",function(){h(n(se,"Error").html(_.get("imgError")))}).one("load",function(){d===le&&setTimeout(function(){var e;t.each(["alt","longdesc","aria-describedby"],function(e,i){var n=t(_.el).attr(i)||t(_.el).attr("data-"+i);n&&U.setAttribute(i,n)}),_.get("retinaImage")&&i.devicePixelRatio>1&&(U.height=U.height/i.devicePixelRatio,U.width=U.width/i.devicePixelRatio),_.get("scalePhotos")&&(o=function(){U.height-=U.height*e,U.width-=U.width*e},_.mw&&U.width>_.mw&&(e=(U.width-_.mw)/U.width,o()),_.mh&&U.height>_.mh&&(e=(U.height-_.mh)/U.height,o())),_.h&&(U.style.marginTop=Math.max(_.mh-U.height,0)/2+"px"),W[1]&&(_.get("loop")||W[z+1])&&(U.style.cursor="pointer",U.onclick=function(){J.next()}),U.style.width=U.width+"px",U.style.height=U.height+"px",h(U)},1)}),U.src=e):e&&M.load(e,_.get("data"),function(e,i){d===le&&h("error"===i?n(se,"Error").html(_.get("xhrError")):t(this).contents())})}var v,y,x,b,T,C,H,k,W,E,L,M,S,F,I,R,K,P,B,O,_,D,j,A,N,z,U,$,q,G,Q,J,V,X={html:!1,photo:!1,iframe:!1,inline:!1,transition:"elastic",speed:300,fadeOut:300,width:!1,initialWidth:"600",innerWidth:!1,maxWidth:!1,height:!1,initialHeight:"450",innerHeight:!1,maxHeight:!1,scalePhotos:!0,scrolling:!0,opacity:.9,preloading:!0,className:!1,overlayClose:!0,escKey:!0,arrowKey:!0,top:!1,bottom:!1,left:!1,right:!1,fixed:!1,data:void 0,closeButton:!0,fastIframe:!0,open:!1,reposition:!0,loop:!0,slideshow:!1,slideshowAuto:!0,slideshowSpeed:2500,slideshowStart:"start slideshow",slideshowStop:"stop slideshow",photoRegex:/\.(gif|png|jp(e|g|eg)|bmp|ico|webp|jxr|svg)((#|\?).*)?$/i,retinaImage:!1,retinaUrl:!1,retinaSuffix:"@2x.$1",current:"image {current} of {total}",previous:"previous",next:"next",close:"close",xhrError:"This content failed to load.",imgError:"This image failed to load.",returnFocus:!0,trapFocus:!0,onOpen:!1,onLoad:!1,onComplete:!1,onCleanup:!1,onClosed:!1,rel:function(){return this.rel},href:function(){return t(this).attr("href")},title:function(){return this.title}},Y="colorbox",Z="cbox",te=Z+"Element",ee=Z+"_open",ie=Z+"_load",ne=Z+"_complete",oe=Z+"_cleanup",re=Z+"_closed",he=Z+"_purge",ae=t("<a/>"),se="div",le=0,de={},ce=function(){function t(){clearTimeout(h)}function e(){(_.get("loop")||W[z+1])&&(t(),h=setTimeout(J.next,_.get("slideshowSpeed")))}function i(){R.html(_.get("slideshowStop")).unbind(s).one(s,n),ae.bind(ne,e).bind(ie,t),y.removeClass(a+"off").addClass(a+"on")}function n(){t(),ae.unbind(ne,e).unbind(ie,t),R.html(_.get("slideshowStart")).unbind(s).one(s,function(){J.next(),i()}),y.removeClass(a+"on").addClass(a+"off")}function o(){r=!1,R.hide(),t(),ae.unbind(ne,e).unbind(ie,t),y.removeClass(a+"off "+a+"on")}var r,h,a=Z+"Slideshow_",s="click."+Z;return function(){r?_.get("slideshow")||(ae.unbind(oe,o),o()):_.get("slideshow")&&W[1]&&(r=!0,ae.one(oe,o),_.get("slideshowAuto")?i():n(),R.show())}}();t[Y]||(t(p),J=t.fn[Y]=t[Y]=function(e,i){var n,o=this;if(e=e||{},t.isFunction(o))o=t("<a/>"),e.open=!0;else if(!o[0])return o;return o[0]?(p(),m()&&(i&&(e.onComplete=i),o.each(function(){var i=t.data(this,Y)||{};t.data(this,Y,t.extend(i,e))}).addClass(te),n=new r(o[0],e),n.get("open")&&f(o[0])),o):o},J.position=function(e,i){function n(){T[0].style.width=k[0].style.width=b[0].style.width=parseInt(y[0].style.width,10)-j+"px",b[0].style.height=C[0].style.height=H[0].style.height=parseInt(y[0].style.height,10)-D+"px"}var r,h,s,l=0,d=0,c=y.offset();if(E.unbind("resize."+Z),y.css({top:-9e4,left:-9e4}),h=E.scrollTop(),s=E.scrollLeft(),_.get("fixed")?(c.top-=h,c.left-=s,y.css({position:"fixed"})):(l=h,d=s,y.css({position:"absolute"})),d+=_.get("right")!==!1?Math.max(E.width()-_.w-N-j-a(_.get("right"),"x"),0):_.get("left")!==!1?a(_.get("left"),"x"):Math.round(Math.max(E.width()-_.w-N-j,0)/2),l+=_.get("bottom")!==!1?Math.max(o()-_.h-A-D-a(_.get("bottom"),"y"),0):_.get("top")!==!1?a(_.get("top"),"y"):Math.round(Math.max(o()-_.h-A-D,0)/2),y.css({top:c.top,left:c.left,visibility:"visible"}),x[0].style.width=x[0].style.height="9999px",r={width:_.w+N+j,height:_.h+A+D,top:l,left:d},e){var g=0;t.each(r,function(t){return r[t]!==de[t]?(g=e,void 0):void 0}),e=g}de=r,e||y.css(r),y.dequeue().animate(r,{duration:e||0,complete:function(){n(),q=!1,x[0].style.width=_.w+N+j+"px",x[0].style.height=_.h+A+D+"px",_.get("reposition")&&setTimeout(function(){E.bind("resize."+Z,J.position)},1),t.isFunction(i)&&i()},step:n})},J.resize=function(t){var e;$&&(t=t||{},t.width&&(_.w=a(t.width,"x")-N-j),t.innerWidth&&(_.w=a(t.innerWidth,"x")),L.css({width:_.w}),t.height&&(_.h=a(t.height,"y")-A-D),t.innerHeight&&(_.h=a(t.innerHeight,"y")),t.innerHeight||t.height||(e=L.scrollTop(),L.css({height:"auto"}),_.h=L.height()),L.css({height:_.h}),e&&L.scrollTop(e),J.position("none"===_.get("transition")?0:_.get("speed")))},J.prep=function(i){function o(){return _.w=_.w||L.width(),_.w=_.mw&&_.mw<_.w?_.mw:_.w,_.w}function a(){return _.h=_.h||L.height(),_.h=_.mh&&_.mh<_.h?_.mh:_.h,_.h}if($){var d,g="none"===_.get("transition")?0:_.get("speed");L.remove(),L=n(se,"LoadedContent").append(i),L.hide().appendTo(M.show()).css({width:o(),overflow:_.get("scrolling")?"auto":"hidden"}).css({height:a()}).prependTo(b),M.hide(),t(U).css({"float":"none"}),c(_.get("className")),d=function(){function i(){t.support.opacity===!1&&y[0].style.removeAttribute("filter")}var n,o,a=W.length;$&&(o=function(){clearTimeout(Q),S.hide(),u(ne),_.get("onComplete")},F.html(_.get("title")).show(),L.show(),a>1?("string"==typeof _.get("current")&&I.html(_.get("current").replace("{current}",z+1).replace("{total}",a)).show(),K[_.get("loop")||a-1>z?"show":"hide"]().html(_.get("next")),P[_.get("loop")||z?"show":"hide"]().html(_.get("previous")),ce(),_.get("preloading")&&t.each([h(-1),h(1)],function(){var i,n=W[this],o=new r(n,t.data(n,Y)),h=o.get("href");h&&s(o,h)&&(h=l(o,h),i=e.createElement("img"),i.src=h)})):O.hide(),_.get("iframe")?(n=e.createElement("iframe"),"frameBorder"in n&&(n.frameBorder=0),"allowTransparency"in n&&(n.allowTransparency="true"),_.get("scrolling")||(n.scrolling="no"),t(n).attr({src:_.get("href"),name:(new Date).getTime(),"class":Z+"Iframe",allowFullScreen:!0}).one("load",o).appendTo(L),ae.one(he,function(){n.src="//about:blank"}),_.get("fastIframe")&&t(n).trigger("load")):o(),"fade"===_.get("transition")?y.fadeTo(g,1,i):i())},"fade"===_.get("transition")?y.fadeTo(g,0,function(){J.position(0,d)}):J.position(g,d)}},J.next=function(){!q&&W[1]&&(_.get("loop")||W[z+1])&&(z=h(1),f(W[z]))},J.prev=function(){!q&&W[1]&&(_.get("loop")||z)&&(z=h(-1),f(W[z]))},J.close=function(){$&&!G&&(G=!0,$=!1,u(oe),_.get("onCleanup"),E.unbind("."+Z),v.fadeTo(_.get("fadeOut")||0,0),y.stop().fadeTo(_.get("fadeOut")||0,0,function(){y.hide(),v.hide(),u(he),L.remove(),setTimeout(function(){G=!1,u(re),_.get("onClosed")},1)}))},J.remove=function(){y&&(y.stop(),t[Y].close(),y.stop(!1,!0).remove(),v.remove(),G=!1,y=null,t("."+te).removeData(Y).removeClass(te),t(e).unbind("click."+Z).unbind("keydown."+Z))},J.element=function(){return t(_.el)},J.settings=X)})(jQuery,document,window);
/*!
 * jQuery Tools v1.2.7 - The missing UI library for the Web
 *
 * tabs/tabs.js
 *
 * NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.
 *
 * http://flowplayer.org/tools/
 *
 */
(function(d){d.tools=d.tools||{version:"v1.2.7"},d.tools.tabs={conf:{tabs:"a",current:"current",onBeforeClick:null,onClick:null,effect:"default",initialEffect:!1,initialIndex:0,event:"click",rotate:!1,slideUpSpeed:400,slideDownSpeed:400,history:!1},addEffect:function(f,g){e[f]=g}};var e={"default":function(f,g){this.getPanes().hide().eq(f).show(),g.call()},fade:function(g,h){var i=this.getConf(),j=i.fadeOutSpeed,f=this.getPanes();j?f.fadeOut(j):f.hide(),f.eq(g).fadeIn(i.fadeInSpeed,h)},slide:function(g,h){var f=this.getConf();this.getPanes().slideUp(f.slideUpSpeed),this.getPanes().eq(g).slideDown(f.slideDownSpeed,h)},ajax:function(f,g){this.getPanes().eq(0).load(this.getTabs().eq(f).attr("href"),g)}},a,b;d.tools.tabs.addEffect("horizontal",function(f,g){if(!a){var h=this.getPanes().eq(f),i=this.getCurrentPane();b||(b=this.getPanes().eq(0).width()),a=!0,h.show(),i.animate({width:0},{step:function(j){h.css("width",b-j)},complete:function(){d(this).hide(),g.call(),a=!1}}),i.length||(g.call(),a=!1)}});function c(q,r,s){var g=this,i=q.add(this),j=q.find(s.tabs),f=r.jquery?r:q.children(r),h;j.length||(j=q.children()),f.length||(f=q.parent().find(r)),f.length||(f=d(r)),d.extend(this,{click:function(l,m){var n=j.eq(l),o=!q.data("tabs");typeof l=="string"&&l.replace("#","")&&(n=j.filter('[href*="'+l.replace("#","")+'"]'),l=Math.max(j.index(n),0));if(s.rotate){var p=j.length-1;if(l<0){return g.click(p,m)}if(l>p){return g.click(0,m)}}if(!n.length){if(h>=0){return g}l=s.initialIndex,n=j.eq(l)}if(l===h){return g}m=m||d.Event(),m.type="onBeforeClick",i.trigger(m,[l]);if(!m.isDefaultPrevented()){var k=o?s.initialEffect&&s.effect||"default":s.effect;e[k].call(g,l,function(){h=l,m.type="onClick",i.trigger(m,[l])}),j.removeClass(s.current),n.addClass(s.current);return g}},getConf:function(){return s},getTabs:function(){return j},getPanes:function(){return f},getCurrentPane:function(){return f.eq(h)},getCurrentTab:function(){return j.eq(h)},getIndex:function(){return h},next:function(){return g.click(h+1)},prev:function(){return g.click(h-1)},destroy:function(){j.off(s.event).removeClass(s.current),f.find('a[href^="#"]').off("click.T");return g}}),d.each("onBeforeClick,onClick".split(","),function(l,k){d.isFunction(s[k])&&d(g).on(k,s[k]),g[k]=function(m){m&&d(g).on(k,m);return g}}),s.history&&d.fn.history&&(d.tools.history.init(j),s.event="history"),j.each(function(k){d(this).on(s.event,function(l){g.click(k,l);return l.preventDefault()})}),f.find('a[href^="#"]').on("click.T",function(k){g.click(d(this).attr("href"),k)}),location.hash&&s.tabs=="a"&&q.find('[href="'+location.hash+'"]').length?g.click(location.hash):(s.initialIndex===0||s.initialIndex>0)&&g.click(s.initialIndex)}d.fn.tabs=function(f,g){var h=this.data("tabs");h&&(h.destroy(),this.removeData("tabs")),d.isFunction(g)&&(g={onBeforeClick:g}),g=d.extend({},d.tools.tabs.conf,g),this.each(function(){h=new c(d(this),f,g),d(this).data("tabs",h)});return g.api?h:this}})(jQuery);eval(function(h,b,i,d,g,f){g=function(a){return(a<b?"":g(parseInt(a/b)))+((a=a%b)>35?String.fromCharCode(a+29):a.toString(36))};if(!"".replace(/^/,String)){while(i--){f[g(i)]=d[i]||g(i)}d=[function(a){return f[a]}];g=function(){return"\\w+"};i=1}while(i--){if(d[i]){h=h.replace(new RegExp("\\b"+g(i)+"\\b","g"),d[i])}}return h}(";5 V=(8(){\"1D 1B\";5 j={o:'o',E:'1y',m:'m',p:'1x',q:'1v',t:'t'},19={\"1u\":1t,\"1q\":1n,\"1m\":11,\"1k\":18,\"1j\":11,\"1i\":18},S=8(a,b){5 d=1h,O=d.1f('a'),b=b||d.17.J,L=b.r(/\\/\\/(.*?)(?::(.*?))?@/)||[];O.J=b;w(5 i N j){a[i]=O[j[i]]||''}a.o=a.o.l(/:$/,'');a.q=a.q.l(/^\\?/,'');a.t=a.t.l(/^#/,'');a.x=L[1]||'';a.y=L[2]||'';a.m=(19[a.o]==a.m||a.m==0)?'':a.m;9(!a.o&&!/^([a-z]+:)?\\/\\//.1d(b)){5 c=T V(d.17.J.r(/(.*\\/)/)[0]),A=c.p.X('../../index.html'),B=a.p.X('../../index.html');A.W();w(5 i=0,C=['o','x','y','E','m'],s=C.Z;i<s;i++){a[C[i]]=c[C[i]]}10(B[0]=='..'){A.W();B.1c()}a.p=(b.1p(0,1)!='/'?A.13('../../index.html'):'')+'/'+B.13('../../index.html')}G{a.p=a.p.l(/^\\/?/,'../../index.html')}14(a)},15=8(s){s=s.l(/\\+/g,' ');s=s.l(/%([1b][0-v-F])%([P][0-v-F])%([P][0-v-F])/g,8(a,b,c,d){5 e=u(b,16)-1e,H=u(c,16)-K;9(e==0&&H<1g){k a}5 f=u(d,16)-K,n=(e<<12)+(H<<6)+f;9(n>1l){k a}k I.R(n)});s=s.l(/%([1o][0-v-F])%([P][0-v-F])/g,8(a,b,c){5 d=u(b,16)-1a;9(d<2){k a}5 e=u(c,16)-K;k I.R((d<<6)+e)});s=s.l(/%([0-7][0-v-F])/g,8(a,b){k I.R(u(b,16))});k s},14=8(g){5 h=g.q;g.q=T(8(c){5 d=/([^=&]+)(=([^&]*))?/g,r;10((r=d.1r(c))){5 f=1s(r[1].l(/\\+/g,' ')),M=r[3]?15(r[3]):'';9(4[f]!=1w){9(!(4[f]D Y)){4[f]=[4[f]]}4[f].1z(M)}G{4[f]=M}}4.1A=8(){w(f N 4){9(!(4[f]D U)){1C 4[f]}}};4.Q=8(){5 s='',e=1E;w(5 i N 4){9(4[i]D U){1F}9(4[i]D Y){5 a=4[i].Z;9(a){w(5 b=0;b<a;b++){s+=s?'&':'';s+=e(i)+'='+e(4[i][b])}}G{s+=(s?'&':'')+e(i)+'='}}G{s+=s?'&':'';s+=e(i)+'='+e(4[i])}}k s}})(h)};k 8(a){4.Q=8(){k((4.o&&(4.o+'://'))+(4.x&&(4.x+(4.y&&(':'+4.y))+'@'))+(4.E&&4.E)+(4.m&&(':'+4.m))+(4.p&&4.p)+(4.q.Q()&&('?'+4.q))+(4.t&&('#'+4.t)))};S(4,a)}}());",62,104,"||||this|var|||function|if|||||||||||return|replace|port||protocol|path|query|match||hash|parseInt|9A|for|user|pass||basePath|selfPath|props|instanceof|host||else|n2|String|href|0x80|auth|value|in|link|89AB|toString|fromCharCode|parse|new|Function|Url|pop|split|Array|length|while|80||join|parseQs|decode||location|443|defaultPorts|0xC0|EF|shift|test|0xE0|createElement|32|document|wss|ws|https|0xFFFF|http|70|CD|substring|gopher|exec|decodeURIComponent|21|ftp|search|null|pathname|hostname|push|clear|strict|delete|use|encodeURIComponent|continue".split("|"),0,{}));(function(c){var b=c.scrollTo=function(e,d,f){c(window).scrollTo(e,d,f)};b.defaults={axis:"xy",duration:parseFloat(c.fn.jquery)>=1.3?0:1,limit:true};b.window=function(d){return c(window)._scrollable()};c.fn._scrollable=function(){return this.map(function(){var e=this,f=!e.nodeName||c.inArray(e.nodeName.toLowerCase(),["iframe","#document","html","body"])!=-1;if(!f){return e}var d=(e.contentWindow||e).document||e.ownerDocument||e;return/webkit/i.test(navigator.userAgent)||d.compatMode=="BackCompat"?d.body:d.documentElement})};c.fn.scrollTo=function(i,h,d){if(typeof h=="object"){d=h;h=0}if(typeof d=="function"){d={onAfter:d}}if(i=="max"){i=9000000000}d=c.extend({},b.defaults,d);h=h||d.duration;d.queue=d.queue&&d.axis.length>1;if(d.queue){h/=2}d.offset=a(d.offset);d.over=a(d.over);return this._scrollable().each(function(){if(i==null){return}var m=this,j=c(m),k=i,g,e={},l=j.is("html,body");switch(typeof k){case"number":case"string":if(/^([+-]=?)?\d+(\.\d+)?(px|%)?$/.test(k)){k=a(k);break}k=c(k,this);if(!k.length){return}case"object":if(k.is||k.style){g=(k=c(k)).offset()}}c.each(d.axis.split(""),function(s,q){var o=q=="x"?"Left":"Top",u=o.toLowerCase(),r="scroll"+o,p=m[r],n=b.max(m,q);if(g){e[r]=g[u]+(l?0:p-j.offset()[u]);if(d.margin){e[r]-=parseInt(k.css("margin"+o))||0;e[r]-=parseInt(k.css("border"+o+"Width"))||0}e[r]+=d.offset[u]||0;if(d.over[u]){e[r]+=k[q=="x"?"width":"height"]()*d.over[u]}}else{var t=k[u];e[r]=t.slice&&t.slice(-1)=="%"?parseFloat(t)/100*n:t}if(d.limit&&/^\d+$/.test(e[r])){e[r]=e[r]<=0?0:Math.min(e[r],n)}if(!s&&d.queue){if(p!=e[r]){f(d.onAfterFirst)}delete e[r]}});f(d.onAfter);function f(n){j.animate(e,h,d.easing,n&&function(){n.call(this,k,d)})}}).end()};b.max=function(h,g){var k=g=="x"?"Width":"Height",f="scroll"+k;if(!c(h).is("html,body")){return h[f]-c(h)[k.toLowerCase()]()}var j="client"+k,i=h.ownerDocument.documentElement,e=h.ownerDocument.body;return Math.max(i[f],e[f])-Math.min(i[j],e[j])};function a(d){return typeof d=="object"?d:{top:d,left:d}}})(jQuery);

(function (a) {
    window.COOP_CA = {
        container_scroll: 0.24,
        tabs: null,
        tabapi: null,
        baron: false,
        init: function () {
            a('a[rel^="ext"], .external, #footer a').attr("target", "_blank");

			if(!$('#customerservices-outer').length ){

				COOP_CA.tabs = a("ul.ca-tabs");
				if (COOP_CA.tabs.length > 0) {
					COOP_CA.initTabs();
						$('.ca-tabs .ca-panes').remove();
						var curTab = $('.ca-tabs a.current').parent('li');
						var panes = $('.ca-panes').clone();
						$(curTab).append(panes);
				}
			}
    //         a(".inline").colorbox({
    //             inline: true,
    //             width: "100%",
				// maxWidth: "945px",
    //             height: "80%",
				// maxHeight: "80%",
    //             opacity: 0.65
    //         });
    //         a(".inline-small").colorbox({
    //             inline: true,
    //             width: "100%",
				// maxWidth: "945px",
    //             height: "50%",
				// maxHeight: "80%",
    //             opacity: 0.65
    //         });
    //         a(".modal-iframe").colorbox({
    //             iframe: true,
    //             width: "100%",
				// maxWidth: "945px",
    //             height: "80%",
				// maxHeight: "80%",
    //             opacity: 0.65
    //         });
    //         a(".modal-noiframe").colorbox({
    //             iframe: false,
    //             width: "100%",
				// maxWidth: "945px",
    //             height: "80%",
				// maxHeight: "80%",
    //             opacity: 0.65
    //         });


            if (a(".spoke-container").length > 0) {
                a("h1").css("display", "none");
                COOP_CA.initButton()
            }
            if (a(".apply-stick").length > 0) {
                COOP_CA.initStickyBar()
            }
        },
        initTabs: function () {
			COOP_CA.tabs.tabs("div.ca-panes > div", {
                effect: "fade",
                initialIndex: 0,
                fadeInSpeed: 100,
                fadeOutSpeed: 100,
				onClick: function() {
					$('.ca-tabs .ca-panes').remove();
					var curTab = $('.ca-tabs a.current').parent('li');
					var panes = $('.ca-panes').clone();
					$(curTab).append(panes);
				}
            });
            COOP_CA.tabapi = COOP_CA.tabs.data("tabs");
            COOP_CA.onselectTab(a("ul.ca-tabs").find(".current").first());
            a(".ca-tabs a").on("click", function () {
				var b = a(this);
				COOP_CA.onselectTab(b);
				 if ($(window).width() < 768){
				setTimeout ( function(){
					$('html, body').animate({
						scrollTop: ( $(".ca-tabs a.current").offset().top - $(".ca-tabs a.current").height() + 25 )
					}, 100);
				},100);
			}
			})
        },
        initButton: function () {
            var e = new Url;
            var f = e.query.o;
            var d = "";
            if (f) {
                switch (f) {
                case "currentaccountsplus":
                    d = "Current Accounts Plus";
                    break;
                case "currentaccountstandard":
                    d = "Current Accounts Standard";
                    break;
                case "student":
                    d = "Student Accounts";
                    break;
                case "cashminder":
                    d = "Cashminder Accounts";
                    break;
                default:
                    d = "Current Accounts"
                }
                d = d + " - Home";
                var c = a(".spoke-button-container .btn");
                c.on("click", function (b) {
                    b.preventDefault();
                    history.back(-1)
                });
                c.find("span").text(d)
            }
        },
        initStickyBar: function () {
            var c = a(window);
            var b = a("#current-accounts-container");
            var e = Math.ceil(b.position().top);
            var f = b.height() + e;
            var g = a("#sticky-footer");
            c.scroll(function () {
                var h = c.scrollTop();
                if ((h / f) <= COOP_CA.container_scroll) {
                    if (COOP_CA.baron) {
                        COOP_CA.baron = false;
                        g.fadeOut()
                    }
                } else {
                    if (!COOP_CA.baron) {
                        COOP_CA.baron = true;
                        g.fadeIn()
                    }
                }
            });
            var d = a("#tc-scroll, .tc-jump");
            a.each(d, function (j, h) {
                var k = a(h);
                var l = k.html();
                k.attr("href", "javascript:void(0);");
                k.html(l)
            });
            d.on("click", function (h) {
                h.preventDefault();
                c.scrollTo("#shelf-important", 1000)
            })
        },
        onselectTab: function (b) {
            var aclass = "arrow";
            a(".ca-tabs .arrow").remove();
			if (b.height() >= 44) {
                aclass = "arrow arrow-double";
            }
            b.parent().append('<div class="' + aclass + '"></div>')

        }
    };
    a(document).on("ready", function () {
        COOP_CA.init();
    })
})(jQuery);


// Litebox lib
!function(t,e){"function"==typeof define&&define.amd?define(function(){return e(t)}):"object"==typeof exports?module.exports=e:t.Litebox=e(t)}(this,function(t){"use strict";function e(e){var s=this;this.opts=i({},u,e),this.rootEl=document.querySelectorAll(this.opts.root)[0],this._createSpinner=function(){var t=document.querySelectorAll(".litebox__spinner");0===t.length?(this.spinner=document.createElement("div"),n(this.spinner,"litebox__spinner"),this.rootEl.appendChild(this.spinner)):this.spinner=t[0]},this._createSpinner(),this.supportedTypes={inline:function(t,e){e(document.getElementById(t).innerHTML)},ajax:function(t,e){n(s.rootEl,"litebox-is-loading"),c("GET",t).success(function(t){o(s.rootEl,"litebox-is-loading"),e(t)}).error(function(t,e){o(s.rootEl,"litebox-is-loading"),s.opts.onAjaxError(t,e)})},iframe:function(t,e){e('<iframe class="litebox__iframe" src="'+t+'" frameborder="0" height="500px" width="100%">')}},this.contentResolved=!1,this._createContainer=function(t){this.container=document.createElement("div"),this.container.style.display="none",n(this.container,this.opts.containerClass),this.contentContainer=document.createElement("div"),this.contentContainer.innerHTML=t,n(this.contentContainer,"litebox__content"),"iframe"===this.opts.type&&(this.contentContainer.style.overflowY="hidden",this.contentContainer.style.paddingRight="0",this.contentContainer.style.paddingLeft="0",this.contentContainer.style.paddingTop="0");var e=document.createElement("a");return e.setAttribute("href","#"),e.setAttribute("data-litebox-close",""),e.innerHTML="&times",n(e,"litebox__close"),a.on(e,"click",function(t){l(t),s.close()}),this.container.appendChild(this.contentContainer),this.container.appendChild(e),this},this._createBgOverlay=function(){var t=document.querySelectorAll(this.opts.bgOverlayClass);return t.length?this.bgOverlay=t:(this.bgOverlay=document.createElement("div"),n(this.bgOverlay,this.opts.bgOverlayClass)),a.on(this.bgOverlay,"click",function(t){l(t),s.close()}),this},this._appendToRoot=function(){return this.rootEl.appendChild(this.container),this.rootEl.appendChild(this.bgOverlay),this},this._getContent=function(t){return this.supportedTypes[this.opts.type](this.opts.contentId,t)},this._launch=function(){"ajax"!==this.opts.type&&o(this.rootEl,"litebox-is-loading"),s.contentResolved?s.open():this._getContent(function(t){s._render(t).open()})},this._render=function(t){return s.contentResolved=!0,this._createContainer(t)._createBgOverlay()._appendToRoot(),this},this._calcDimensions=function(){var e=this.contentContainer.clientHeight+50,n=Math.max(document.documentElement.clientHeight,t.innerHeight||0);.8*n>=e&&(this.container.style.maxHeight=Math.round(e)+"px");var o=n/2-this.container.clientHeight/2,i=(t.scrollY||document.documentElement.scrollTop)+o;this.container.style.top=Math.round(i)+"px",this.contentContainer.style.height="100%"},a.on(this.opts.el,"click",function(t){l(t),s._launch()}),this.opts.closeOnEsc&&a.on(document,"keydown",function(t){27===t.which&&s.close()})}var n=function(t,e){"classList"in document.documentElement?t.classList.add(e):t.className+=" "+e},o=function(t,e){"classList"in document.documentElement?t.classList.remove(e):t.className=t.className.replace(new RegExp("(^|\\b)"+e.split(" ").join("|")+"(\\b|$)","gi")," ")},i=function(t){t=t||{};for(var e=1;e<arguments.length;e++)if(arguments[e])for(var n in arguments[e])arguments[e].hasOwnProperty(n)&&(t[n]=arguments[e][n]);return t},s=function(t){return t.style.display="",t},r=function(t){return t.style.display="none",t},c=function(e,n,o){var i=function(t){var e;try{e=JSON.parse(t.responseText)}catch(n){e=t.responseText}return[e,t]},s={success:function(){},error:function(){}},r=t.XMLHttpRequest||ActiveXObject,c=new r("MSXML2.XMLHTTP.3.0");c.open(e,n,!0),c.setRequestHeader("Content-type","application/x-www-form-urlencoded"),c.onreadystatechange=function(){4===c.readyState&&(c.status>=200&&c.status<300?s.success.apply(s,i(c)):s.error.apply(s,i(c)))},c.send(o);var a={success:function(t){return s.success=t,a},error:function(t){return s.error=t,a}};return a},a={on:function(t,e,n){document.addEventListener?t.addEventListener(e,n,!1):t.attachEvent("on"+e,n)},off:function(t,e,n){document.removeEventListener?t.removeEventListener(e,n):t.detachEvent("on"+e,n)}},l=function(t){t.preventDefault?t.preventDefault():t.returnValue=!1},u={el:null,type:null,contentId:null,containerClass:"litebox",root:"body",rootOpenClass:"litebox-is-open",bgOverlayClass:"litebox-bg-overlay",closeOnEsc:!0,onOpen:function(){},onClose:function(){},onAjaxError:function(){}};return e.init=function(t){var n=t.el,o={type:n.getAttribute("data-litebox"),contentId:n.getAttribute("data-litebox-content")};return new e(i(o,t))},e.prototype={open:function(){return n(this.rootEl,this.opts.rootOpenClass),s(this.container),this._calcDimensions(),this.contentContainer.scrollTop=0,this.opts.onOpen(this.container),this},close:function(){return o(this.rootEl,this.opts.rootOpenClass),r(this.container),this.opts.onClose(this.container),this}},e}),$.fn.litebox=function(t){return this.length?this.each(function(){$.data(this,"litebox",Litebox.init($.extend(t,{el:this})))}):this};

// bootstrap the liteboxes on the page
$(function () {

	var fixIOS = function () {
		if (/iPhone|iPod|iPad/g.test(navigator.userAgent)) {
			$('.litebox__iframe').wrap(function(){
			    var $this = $(this);
			    return $('<div />').addClass('litebox-iframe-wrapper').css({
			        width: $this.attr('width'),
			        height: $this.attr('height')
			    });
			});

			$('.litebox__iframe').attr('height', '100%');
		}
	};

	var errorContainer = $('<div/>').html('<div id="litebox-error-msg"><div style="text-align:center;"><h3 style="padding:0;color:#f93 !important;">Sorry, there was a problem whilst getting the content.<h3></div></div>').css('display', 'none').appendTo('body');
	var errorLitebox = Litebox.init({
		el: errorContainer[0],
		type: 'inline',
		contentId: 'litebox-error-msg'
	});

	$('.inline').add('.inline-small').each(function () {
		var self = $(this);

		self.litebox({
			type: 'inline',
			contentId: self.attr('href').substring(1),
			onOpen: function (el) {
				fixIOS();
			},
		    onClose: function (el) {},
		    onAjaxError: function () {
		    	errorLitebox._launch();
		    }
		});
	});

	$('.fancybox-effect').each(function () {
		var self = $(this);

		self.litebox({
			type: self.hasClass('fancybox.iframe') ? 'iframe' : 'inline',
			contentId: self.hasClass('fancybox.iframe') ? self.attr('href') : self.attr('href').substring(1),
			onOpen: function (el) {
				fixIOS();
			},
		    onClose: function (el) {},
		    onAjaxError: function () {
		    	errorLitebox._launch();
		    }
		});
	});

	$('.modal-iframe').each(function () {
		var self = $(this);

		self.litebox({
			type: 'ajax',
			contentId: self.attr('href'),
			onOpen: function (el) {
				fixIOS();
			},
		    onClose: function (el) {},
		    onAjaxError: function () {
		    	errorLitebox._launch();
		    }
		});
	});



});
