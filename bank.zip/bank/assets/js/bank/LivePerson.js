//Dynamically set empty div for LivePerson sidebar
$(document).ready(function() {
	var myDiv = document.createElement("div");
		myDiv.setAttribute("id", "lpButtonDiv-cooperativebank-sales");
		document.body.appendChild(myDiv);
    }
);