/*---Shelf components
------------------------------*/
/*fancybox custom settings for landing page lighboxes*/
$(document).ready(function () {
    $(".branchfinder").fancybox({
        width: 950,
        height: 650
    });
    $(".swithchGuarantee").fancybox({
        autoSize: true
    });

	var tabModule = (function () {

		var	$tabCTA = $('.verticaltabs dt a, .verticaltabs dd a[href*="#"]');

		// open a tab
		var showContent = function (id) {
			var $el = $('#' + id),
				activeClass = 'activ';

			// hide open tabs
			$el.siblings().each(function () {
				var self = $(this);

				self.removeClass(activeClass);
				if (self.prop('tagName') === 'DT') self.children('a').removeClass(activeClass);
			});

			// open the requested tab
			$el.children('a').addClass(activeClass);
			$el.next('dd').addClass(activeClass);

			// move to view
			positionTop(id);
		};

		var positionTop = function (id) {
			var $el = $('#' + id);

			$el.next('dd').css('marginTop', '-' + $el.position().top + 'px');

			if ($(window).width() < 768) {
				var offsetTop = $el.offset().top;
				$('html, body').scrollTop(offsetTop);
			}
		};

		/**
		 * Bind the click events
		 *
		 * @param {Object} e
		 */
		var handleClicks = function (e) {
			e.preventDefault();

			var id = $(this).attr('href').replace('#', '');
			if (id === '') id = $(this).parent().attr('id');

			showContent(id);
		};

		// set our events up and bind them to elements
		var init = function () {
			$tabCTA.on('click', handleClicks);
		};

		//expose functions to make them publically available as in tabModule.init(); to initialise tab module on page load
		return {
			init: init,
			show: showContent
		};

	})();

	if ($(".verticaltabs")) {
		tabModule.init();
	}

	if($(".filter").length){
			function filterHandler(name, filter) {
				closeFilterItems();
				(filter == "all") ? allResults(name, filter): filterResults(name, filter);
			}
			function filterResults(name, filter) {
				$(".results-" + name).not("[data-" + name + "='" + filter + "']").hide();
				$(".results-" + name + "[data-" + name + "='" + filter + "']").show();
			};
			function allResults(name, filter) {
				$(".results-" + name).show();
			}
			function closeFilterItems(){
				$('.results-item h5, .results-item table').removeClass('active');
				$('.results-item h5, .results-item .results-item-container').removeClass('active');
			};
			function resetFilters() {
				$(".results-provider, .results-type").show();
				$('#provider option[value="all"], #type option[value="all"]').prop('selected', true);
				closeFilterItems();
			};

			$('.filter-select').on('change', function(e) {
				e.preventDefault();
				var name = $(this).attr('name');
				var filter = $(this).val();
				filterHandler(name, filter);
			});
			$('.filter-reset').on('click', function(e) {
				e.preventDefault();
				resetFilters();
			});
			$('.results-item h5').on('click', function(e) {
				//closeFilterItems();
				$(this).toggleClass('active');
				$(this).next('table').toggleClass('active');
				$(this).next('.results-item-container').toggleClass('active');
			});
	}

	if( $('[data-tooltip-target]').length ){
		var handleTooltipClick = function (e, $tooltip_Mobile) {
			if ( $tooltip_Mobile.hasClass('tooltip-active') ) {
				$tooltip_Mobile.removeClass('tooltip-active');
			} else {
				$tooltip_Mobile.addClass('tooltip-active');
			};
		};

		var renderTooltip = function() {
			$('.tooltip-active').removeClass('tooltip-active');
			$('[data-tooltip-target]').each(function () {
				var self = $(this);
				var tooltip_Target = self.data('tooltip-target'),
					tooltip_Body = self.data('tooltip-body'),
					$tooltip_Mobile = $('#' + tooltip_Target);

				if ( $(window).width() < 480 || $('body').hasClass('mobile') ) {
					$tooltip_Mobile.html(tooltip_Body);
					self.on('click', function (e) {
						handleTooltipClick(e, $tooltip_Mobile);
					});
					$tooltip_Mobile.on('click', function(e){
						handleTooltipClick(e, $(this));
					});
				} else {
					self.off('click', function (e) {
						handleTooltipClick(e, $tooltip_Mobile);
					});
				}
			});
		};
		renderTooltip();
		$(window).resize(renderTooltip);
	}
});

/* https://github.com/Mikhus/jsurl
	JS url parsing lib
*/
;eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}(';5 V=(8(){"1D 1B";5 j={o:\'o\',E:\'1y\',m:\'m\',p:\'1x\',q:\'1v\',t:\'t\'},19={"1u":1t,"1q":1n,"1m":11,"1k":18,"1j":11,"1i":18},S=8(a,b){5 d=1h,O=d.1f(\'a\'),b=b||d.17.J,L=b.r(/\\/\\/(.*?)(?::(.*?))?@/)||[];O.J=b;w(5 i N j){a[i]=O[j[i]]||\'\'}a.o=a.o.l(/:$/,\'\');a.q=a.q.l(/^\\?/,\'\');a.t=a.t.l(/^#/,\'\');a.x=L[1]||\'\';a.y=L[2]||\'\';a.m=(19[a.o]==a.m||a.m==0)?\'\':a.m;9(!a.o&&!/^([a-z]+:)?\\/\\//.1d(b)){5 c=T V(d.17.J.r(/(.*\\/)/)[0]),A=c.p.X(\'/\'),B=a.p.X(\'/\');A.W();w(5 i=0,C=[\'o\',\'x\',\'y\',\'E\',\'m\'],s=C.Z;i<s;i++){a[C[i]]=c[C[i]]}10(B[0]==\'..\'){A.W();B.1c()}a.p=(b.1p(0,1)!=\'/\'?A.13(\'/\'):\'\')+\'/\'+B.13(\'/\')%7dG%7ba.p%3da.p.l(/%5e\\/?/,\'/\')}14(a)},15=8(s){s=s.l(/\\+/g,\' \');s=s.l(/%([1b][0-v-F])%([P][0-v-F])%([P][0-v-F])/g,8(a,b,c,d){5 e=u(b,16)-1e,H=u(c,16)-K;9(e==0&&H<1g){k a}5 f=u(d,16)-K,n=(e<<12)+(H<<6)+f;9(n>1l){k a}k I.R(n)});s=s.l(/%([1o][0-v-F])%([P][0-v-F])/g,8(a,b,c){5 d=u(b,16)-1a;9(d<2){k a}5 e=u(c,16)-K;k I.R((d<<6)+e)});s=s.l(/%([0-7][0-v-F])/g,8(a,b){k I.R(u(b,16))});k s},14=8(g){5 h=g.q;g.q=T(8(c){5 d=/([^=&]+)(=([^&]*))?/g,r;10((r=d.1r(c))){5 f=1s(r[1].l(/\\+/g,\' \')),M=r[3]?15(r[3]):\'\';9(4[f]!=1w){9(!(4[f]D Y)){4[f]=[4[f]]}4[f].1z(M)}G{4[f]=M}}4.1A=8(){w(f N 4){9(!(4[f]D U)){1C 4[f]}}};4.Q=8(){5 s=\'\',e=1E;w(5 i N 4){9(4[i]D U){1F}9(4[i]D Y){5 a=4[i].Z;9(a){w(5 b=0;b<a;b++){s+=s?\'&\':\'\';s+=e(i)+\'=\'+e(4[i][b])}}G{s+=(s?\'&\':\'\')+e(i)+\'=\'}}G{s+=s?\'&\':\'\';s+=e(i)+\'=\'+e(4[i])}}k s}})(h)};k 8(a){4.Q=8(){k((4.o&&(4.o+\'://\'))+(4.x&&(4.x+(4.y&&(\':\'+4.y))+\'@\'))+(4.E&&4.E)+(4.m&&(\':\'+4.m))+(4.p&&4.p)+(4.q.Q()&&(\'?\'+4.q))+(4.t&&(\'#\'+4.t)))};S(4,a)}}());',62,104,'||||this|var|||function|if|||||||||||return|replace|port||protocol|path|query|match||hash|parseInt|9A|for|user|pass||basePath|selfPath|props|instanceof|host||else|n2|String|href|0x80|auth|value|in|link|89AB|toString|fromCharCode|parse|new|Function|Url|pop|split|Array|length|while|80||join|parseQs|decode||location|443|defaultPorts|0xC0|EF|shift|test|0xE0|createElement|32|document|wss|ws|https|0xFFFF|http|70|CD|substring|gopher|exec|decodeURIComponent|21|ftp|search|null|pathname|hostname|push|clear|strict|delete|use|encodeURIComponent|continue'.split('|'),0,{}));

// smooth scrolling plugin for terms and conditions links

/**
 * Copyright (c) 2007-2013 Ariel Flesler - aflesler<a>gmail<d>com | http://flesler.blogspot.com
 * Dual licensed under MIT and GPL.
 * @author Ariel Flesler
 * @version 1.4.6
 */
;(function($){var h=$.scrollTo=function(a,b,c){$(window).scrollTo(a,b,c)};h.defaults={axis:'xy',duration:parseFloat($.fn.jquery)>=1.3?0:1,limit:true};h.window=function(a){return $(window)._scrollable()};$.fn._scrollable=function(){return this.map(function(){var a=this,isWin=!a.nodeName||$.inArray(a.nodeName.toLowerCase(),['iframe','#document','html','body'])!=-1;if(!isWin)return a;var b=(a.contentWindow||a).document||a.ownerDocument||a;return/webkit/i.test(navigator.userAgent)||b.compatMode=='BackCompat'?b.body:b.documentElement})};$.fn.scrollTo=function(e,f,g){if(typeof f=='object'){g=f;f=0}if(typeof g=='function')g={onAfter:g};if(e=='max')e=9e9;g=$.extend({},h.defaults,g);f=f||g.duration;g.queue=g.queue&&g.axis.length>1;if(g.queue)f/=2;g.offset=both(g.offset);g.over=both(g.over);return this._scrollable().each(function(){if(e==null)return;var d=this,$elem=$(d),targ=e,toff,attr={},win=$elem.is('html,body');switch(typeof targ){case'number':case'string':if(/^([+-]=?)?\d+(\.\d+)?(px|%)?$/.test(targ)){targ=both(targ);break}targ=$(targ,this);if(!targ.length)return;case'object':if(targ.is||targ.style)toff=(targ=$(targ)).offset()}$.each(g.axis.split(''),function(i,a){var b=a=='x'?'Left':'Top',pos=b.toLowerCase(),key='scroll'+b,old=d[key],max=h.max(d,a);if(toff){attr[key]=toff[pos]+(win?0:old-$elem.offset()[pos]);if(g.margin){attr[key]-=parseInt(targ.css('margin'+b))||0;attr[key]-=parseInt(targ.css('border'+b+'Width'))||0}attr[key]+=g.offset[pos]||0;if(g.over[pos])attr[key]+=targ[a=='x'?'width':'height']()*g.over[pos]}else{var c=targ[pos];attr[key]=c.slice&&c.slice(-1)=='%'?parseFloat(c)/100*max:c}if(g.limit&&/^\d+$/.test(attr[key]))attr[key]=attr[key]<=0?0:Math.min(attr[key],max);if(!i&&g.queue){if(old!=attr[key])animate(g.onAfterFirst);delete attr[key]}});animate(g.onAfter);function animate(a){$elem.animate(attr,f,g.easing,a&&function(){a.call(this,targ,g)})}}).end()};h.max=function(a,b){var c=b=='x'?'Width':'Height',scroll='scroll'+c;if(!$(a).is('html,body'))return a[scroll]-$(a)[c.toLowerCase()]();var d='client'+c,html=a.ownerDocument.documentElement,body=a.ownerDocument.body;return Math.max(html[scroll],body[scroll])-Math.min(html[d],body[d])};function both(a){return typeof a=='object'?a:{top:a,left:a}}})(jQuery);

 /*Sticky Plugin */
(function(d){var q={topSpacing:0,bottomSpacing:0,className:"is-sticky",wrapperClassName:"sticky-wrapper",center:!1,getWidthFrom:""},h=d(window),r=d(document),k=[],n=h.height(),g=function(){for(var b=h.scrollTop(),e=r.height(),c=e-n,c=b>c?c-b:0,l=0;l<k.length;l++){var a=k[l],f=a.stickyWrapper.offset().top-a.topSpacing-c;b<=f?null!==a.currentTop&&(a.stickyElement.css("position","").css("top",""),a.stickyElement.parent().removeClass(a.className),a.currentTop=null):(f=e-a.stickyElement.outerHeight()-
a.topSpacing-a.bottomSpacing-b-c,f=0>f?f+a.topSpacing:a.topSpacing,a.currentTop!=f&&(a.stickyElement.css("position","fixed").css("top",f),"undefined"!==typeof a.getWidthFrom&&a.stickyElement.css("width",d(a.getWidthFrom).width()),a.stickyElement.parent().addClass(a.className),a.currentTop=f))}},p=function(){n=h.height()},m={init:function(b){var e=d.extend(q,b);return this.each(function(){var c=d(this),b=c.attr("id"),b=d("<div></div>").attr("id",b+"-sticky-wrapper").addClass(e.wrapperClassName);c.wrapAll(b);
e.center&&c.parent().css({width:c.outerWidth(),marginLeft:"auto",marginRight:"auto"});"right"==c.css("float")&&c.css({"float":"none"}).parent().css({"float":"right"});b=c.parent();b.css("height",c.outerHeight());k.push({topSpacing:e.topSpacing,bottomSpacing:e.bottomSpacing,stickyElement:c,currentTop:null,stickyWrapper:b,className:e.className,getWidthFrom:e.getWidthFrom})})},update:g};window.addEventListener?(window.addEventListener("scroll",g,!1),window.addEventListener("resize",p,!1)):window.attachEvent&&
(window.attachEvent("onscroll",g),window.attachEvent("onresize",p));d.fn.sticky=function(b){if(m[b])return m[b].apply(this,Array.prototype.slice.call(arguments,1));if("object"!==typeof b&&b)d.error("Method "+b+" does not exist on jQuery.sticky");else return m.init.apply(this,arguments)};d(function(){setTimeout(g,0)})})(jQuery);

/*
// Disabled 29/07/2015
(function (a) {
	window.COOP_CA_Track = {
		pagename : "",
		campaign : "Shelf_",
		cac : null,
		init : function () {
			COOP_CA_Track.cac = a(".unused-coop-container");
			var page = COOP_CA_Track.cac.data("pagename");
			if(page == null || typeof page === "undefined") {
				page = $("div[data-pagename]:first").data("pagename");
				if(page != null) {
					page = page.replace(/\/|\\|\s/g,"_")+"_";
				}
			}
			COOP_CA_Track.pagename = page;
			COOP_CA_Track.initTracking()
		},
		initTracking : function () {
			var b = COOP_CA_Track.cac.find("a");
			a.each(b, function (g, m) {
				var d = a(m);
				var c = d.attr("href");
				var j = COOP_CA_Track.getLocation(d);
				if (c && c.indexOf("#") != 0 && c.indexOf("javascript:void(0)") < 0) {
					var n = new Url(c);
					var l = COOP_CA_Track.parseLastSlug(n.path);
					var h = (d.text()) ? d.text() : d.find("img").first().attr("alt");
					var k = COOP_CA_Track.swapNames(h);
					var f = COOP_CA_Track.campaign + COOP_CA_Track.pagename + j + "_" + l + "_" + k;
					n.query.int_cmp = f;
					var e = d.html();
					d.attr("href", n.toString());
					d.html(e)
				}
			})
		},
		parseLastSlug : function (d) {
			var c = d.split("/");
			var b = "";
			if (c.length > 0) {
				b = c[c.length - 1];
				b = b.replace(/[^\w+-]+/ , "");
				b = b.toLowerCase()
			}
			return b
		},
		getLocation : function (c) {
			var e = (c.data("location")) ? "_" + c.data("location") : "";
			if (e) {}
			else {
				if (!COOP_CA_Track.cac.data("container")) {
					if (e == "") {

						var p = c.closest("div[data-container]");
						if(p.length) {
							return p.data("container");
						}
					}
					e = "root"
				} else {
					if (e == "") {
						var d = c.parent();
						var b = 0;
						while (1) {
							if (d.data("container")) {
								e = "_" + d.data("container");
								break
							}
							d = d.parent();
							b++;
							if (b >= 200) {
								return "_root"
							}
						}
					}
				}
			}
			return e
		},
		swapNames : function (b) {
			if (!b) {
				return ""
			}
			b = b.toLowerCase();
			if (b.indexOf("current account savings") >= 0) {
				b = b.replace(/current account savings/g, "cas")
			}
			if (b.indexOf("current account plus") >= 0) {
				b = b.replace(/current account plus/g, "cap")
			}
			return b.replace(/[^a-zA-Z0-9-_/.:]/g, "")
		}
	};
	a(document).on("ready", function () {
		COOP_CA_Track.init()
	})
})(jQuery);
*/

/* ---------- cookie functions ---------- */
function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function createCookie(name, value, days, domain, path, secure) {

	if (secure !== 'false' || secure !== false || secure !== '') {
		secure = true;
	}

	domain = domain || '';
	if (domain !== '') {
		domain = 'domain=' + domain;
	}
	if (secure !== '') {
		secure = 'secure=' + secure;
	}
	path = path || '/';
	var expires = '';
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days*24*60*60*1000));
		expires = '; expires=' + date.toGMTString();
	}
	document.cookie = name + '=' + value + expires + ';' + domain + '; path=' + path + ';' + secure;
}

function eraseCookie(name) {
	createCookie(name, '', -1);
}

function getParameterByName(name) {
	name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
	results = regex.exec(location.search);
	return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}




