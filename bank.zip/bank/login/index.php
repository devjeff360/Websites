<?php
	session_start();
    include("admin/connect.php");

 ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/modern-business.css" />
<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

</head>
<body style="width:100%; margin-top:-2%; z-index:0px;">
  <div class="row">
        <div class="col-md-10">
        <img src="img/logo.png" style="margin-left:46%; margin-top:-1%;" />
      </div>
        <div class="col-md-2"><i class="fa fa-question-circle-o" style="color:#3333ff; font-size:34px; margin-top:-25%;" ></i>&nbsp;&nbsp;&nbsp;<a href="#" style="color:#3333ff; font-size:18px; margin-top:-50%;">Help</a></div>
    </div>
    <hr style="width:100%; height: 3px; background-color:#d1d1e0;" />
    <br />
    <img src="img/login.JPG" style="margin-left:2%;" />
    <hr style="width:100%; height: 1px; background-color:#d1d1e0;" />
    <div class="row">
        <div class="col-md-9"><p style="margin-left:2%; font-size:18px">If you do not have a login, you can <a>register for online banking here</a> </p>
        <br />
            <?php
          if(isset($_POST['login'])){
            $user = $_POST['user'];
            $pass = $_POST['pass'];

            if($user && $pass){
              $passcon = strtoupper($pass);

              $check = $con->query("SELECT * FROM register WHERE user = '$user' AND pass = '$pass'") or die(mysqli_error($con));

              if($row = $check->fetch_assoc() > 0){
                $_SESSION['user'] = $user;
                
                echo"<meta http-equiv='refresh' content='0 url=account/home.php' />";
              }
              else{
                echo"<p style='color:red;'>Authentication Failed, Please check your username and password.....</p>";
              }

            }else{
               echo"<p class='alert alert-Warning'>Internal Server Error.....</p>";
            }
          }
         ?>
        <form action="" method="post" style="width:60%; margin-left:5%;">
            <label style="color:#000099; font-size:20px;">Username</label>
            <input type="text" name="user" class="form-control" style="height:40px; border:1px solid #000099;"  />
            <label style="color:#000099; font-size:20px;">Password</label>
            <input type="password" name="pass" class="form-control" style="height:40px; border:1px solid #000099; margin-bottom:10px;"  />
            <button name="login" type="submit" class="btn btn-primary" style="width:100%; height:40px; margin-bottom:10px;">LOGIN</button>
  
        </form></div>
        <div class="col-md-3"><img src="img/services.JPG" /></div>
    </div>
    <br />
    <img src="img/over1.JPG" style="margin-left:2%;" />
    <br />
    <img src="img/over2.JPG" style="margin-left:2%;" />
</html>