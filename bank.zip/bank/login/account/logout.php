<?php 
require_once('connect.php');//start session at default constructor


unset($_SESSION['user']);

header('location: index.php');
