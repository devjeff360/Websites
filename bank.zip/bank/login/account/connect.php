<?
    $con = new mysqli("localhost","root","","bank") or die("Cannot Connect");
?>