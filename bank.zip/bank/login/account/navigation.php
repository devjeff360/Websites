  <li class="header">MAIN NAVIGATION</li>
           
    <li class="treeview">
      <a href="home.php">
        <i class="fa fa-home"></i>
        <span>Home</span>
      </a>
    </li>

    <li class="treeview">
      <a href="alltrans.php">
        <i class="fa fa-th-list"></i>
        <span>Transactions</span>
      </a>
    </li>

    <li class="treeview">
      <a href="bene.php">
        <i class="fa fa-users"></i>
        <span>Beneficiaries</span>
      </a>
    </li>

<li class="treeview">
      <a href="transfer.php">
        <i class="fa fa-print"></i>
        <span>Transfer</span>
      </a>
    </li>

<li class="treeview">
      <a href="card.php">
        <i class="fa fa-cc"></i>
        <span>Cards and Cheques</span>
      </a>
    </li>

	<li><a href="../index.php"><i class="fa fa-circle-o text-red"></i> 
		<span>Logout</span></a>
	</li>