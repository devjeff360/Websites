<?php
    include_once("connect.php");
    
    $id = $_GET['id'];


    
    $getdet = $con->query("SELECT * FROM transhist WHERE id = '$id'") or die (mysqli_error($con));

    while($row = $getdet->fetch_assoc()){
        $account = $row['account'];
        $ttype = $row['ttype'];
        $amount = $row['amount'];
    }

$getbal = $con->query("SELECT * FROM register WHERE account = '$account'") or die (mysqli_error($con));

    while($col = $getbal->fetch_assoc()){
       
        $oldbal = $col['bal'];
    }
    
if($ttype != "deposit"){
            $newbal = $oldbal+$amount;
        }
        else{
             $newbal = $oldbal-$amount;
        }

$update = $con->query("UPDATE register SET bal = '$newbal' WHERE account = '$account'") or die(mysqli_error($con));
$delete = $con->query("DELETE FROM transhist WHERE id = '$id'") or die(mysqli_error($con));

if($update && $delete == TRUE){
     echo"<script>alert('Transaction deleted successfully.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=alltrans.php?id=$account' />";
}
else{
     echo"<script>alert('Error deleting transaction.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=alltrans.php?id=$account' />";
}
?>