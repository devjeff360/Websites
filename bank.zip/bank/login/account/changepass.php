<?php
    include_once("connect.php");

    if(isset($_POST['change'])){
        $pass = $_POST['pass'];
        $pass2 = $_POST['pass2'];
        
        $update = $con->query("UPDATE admin SET pass = '$pass'") or die(mysqli_error($con));
        
        if($update == TRUE){
            echo"<script>alert('Password Changed Successfully');</script>";
            echo"<meta http-equiv='refresh' content='0 url=home.php' />";
        }
        else{
            echo"<script>alert('error changing password');</script>";
            echo"<meta http-equiv='refresh' content='0 url=home.php' />";
        }
    }
?>