<?php
    include_once("connect.php");

    if(isset($_POST['add'])){
        $name = $_POST['name'];
        $account = $_POST['account'];
        $bal = $_POST['bal'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        
        $insert = $con->query("INSERT INTO register VALUES('','$name','$account','$bal','$user','$pass')") or die(mysqli_error($con));
        
        if($insert == TRUE){
            echo"<script>alert('Account Added Successfully');</script>";
            echo"<meta http-equiv='refresh' content='0 url=home.php' />";
        }
        else{
             echo"<script>alert('Process Failed');</script>";
            echo"<meta http-equiv='refresh' content='0 url=home.php' />";
        }
        
    }
?>