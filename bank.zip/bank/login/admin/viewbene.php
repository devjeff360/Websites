<?php session_start();

  include("connect.php");
  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=index.php/\" />";
  
  }
else {
  $id = $_GET['id'];
    
   
    
    if(isset($_POST['save'])){
        $name = $_POST['name'];
        $acct = $_POST['account'];
        $bank = $_POST['bank'];
        $acctno = $_POST['acctno'];
        $status = $_POST['status'];
        
      $insert = $con->query("INSERT INTO bene VALUES ('','$acct','$name','$acctno','$bank','$status')") or die(mysqli_error($con));
        
        if($insert == TRUE){
            echo"<script>alert('Record Updated');</script>";
        }
        else{
            echo"<script>alert('error Updating Record');</script>";
        }
    }
}
  ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Administrator</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">
    <!-- Font Awesome -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="assets/css/font-awesome.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <link href="assets/css/dataTables.bootstrap.min.css" rel="stylesheet">

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">

       <header class="main-header">
        <!-- Logo -->
        <a href="home.php" class="logo" style="background-color:white;">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          
          <!-- logo for regular state and mobile devices -->
         <img src="logo.png" alt="" height="60" width="180">
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only"> Toggle navigation</span>
            <span class="icon-bar">Toggle navigation</span>
            <span class="icon-bar">Toggle navigation</span>
            <span class="icon-bar">Toggle navigation</span>
          </a>
        </nav>
      </header>

      <!-- =============================================== -->

      <!-- Left side column. contains the sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
          <?php include_once('navigation.php'); ?>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- =============================================== -->

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <small>Welcome Administrator!</small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
           <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>Name:</th>
                        <th>Bank Name:</th>
                        <th>Account Number:</th>
                        <th>Status:</th>
                        <th>Action:</th>
                    </tr>
                    </thead>
                    
                    <?php
                        $getacct = $con->query("SELECT * FROM bene WHERE account = '$id'") or die(mysqli_error($con));
                            
                        while($row = $getacct->fetch_assoc()){
                            $bname = $row['bname'];
                            $acctno = $row['acctno'];
                            $bank = $row['bank'];
                            $status = $row['status'];
                            $bid = $row['id'];
                    ?>
                    <tbody>
                    <tr>
                        <td><?php echo ucwords($bname); ?></td>
                        <td><?php echo ucwords($bank); ?></td>
                        <td><?php echo $acctno; ?></td>
                        <td><?php echo $status; ?></td>
                        <td><a href="deletebene.php?id=<?php echo $bid; ?>" title="Delete Beneficiaries" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                    </tr>
                    <?php } ?>
                    </tbody>
                    
                </table>
                </div><!-- /.box-body -->
            <div class="box-footer">
              <!-- Footer -->
            </div><!-- /.box-footer-->
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      

      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- modal here -->
    <?php include_once('modal/change_password.php'); ?>
    <?php include_once('modal/msg.php'); ?>
    <?php include_once('script.php'); ?>

  </body>
</html>
