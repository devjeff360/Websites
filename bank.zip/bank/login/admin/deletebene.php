<?php
    include("connect.php");

    $id = $_GET['id'];

    $delete = $con->query("DELETE FROM bene WHERE id = '$id'") or die(mysqli_error($con));

    if($delete == TRUE){
     echo"<script>alert('Transaction deleted successfully.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=bene.php' />";
}
else{
     echo"<script>alert('Error deleting transaction.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=bene.php' />";
}
?>