  <li class="header">MAIN NAVIGATION</li>
           
    <li class="treeview">
      <a href="home.php">
        <i class="fa fa-home"></i>
        <span>Home</span>
      </a>
    </li>

    <li class="treeview">
      <a href="transactions.php">
        <i class="fa fa-th-list"></i>
        <span>Transactions</span>
      </a>
    </li>

    <li class="treeview">
      <a href="allacct.php">
        <i class="fa fa-print"></i>
        <span>All accounts</span>
      </a>
    </li>

<li class="treeview">
      <a href="bene.php">
        <i class="fa fa-users"></i>
        <span>Beneficiaries</span>
      </a>
    </li>

<li class="header">SETTINGS</li>
	<li><a id="changePass" href="#"><i class="fa fa-circle-o text-yellow"></i> 
		<span>Change Password</span></a>
	</li>

	<li><a href="index.php"><i class="fa fa-circle-o text-red"></i> 
		<span>Logout</span></a>
	</li>