<?php
    include("connect.php");

    $id = $_GET['id'];

    $delete = $con->query("DELETE FROM register WHERE account = '$id'") or die(mysqli_error($con));

    if($delete == TRUE){
     echo"<script>alert('Account deleted successfully.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allacct.php' />";
}
else{
     echo"<script>alert('Error deleting account.');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allacct.php' />";
}
?>