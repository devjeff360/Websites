<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SCWAY</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/font-awesome.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<style>
    body{
         background-color:black;
    }
.dropbtn {
    background-color:;
    color: #222;
    padding: 16px;
    font-size: 16px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 250px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color:;}
    
  .flash {
  background-color: #004A7F;
  -webkit-border-radius: 10px;
  border-radius: 0px;
  border: none;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Arial;
  font-size: 14px;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;
}
@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
</head>
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" style="margin-top:-25%; height:600%; width:100%;" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li> 
						<li><a href="about.php">About Us</a></li>
                        <li class="dropdown active"><a href="" class="dropbtn">Membership</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="atcard.php">Buy an Athlete Card</a></li>
												<li><a href="clubmem.php">Club Membership</a></li>
												<li><a href="const.php">Club locator</a></li>
												<li><a href="const.php">Join a Dual Team as a Free Agent</a></li>
												<li><a href="coachcard.php">Coaches Card</a></li>
												<li><a href="const.php">Officials</a></li>
												<li><a href="vid.php">Video Tutorials</a></li>
											</ul>
										</li> 
                        <li class="dropdown"><a href="" class="dropbtn">Events</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="upevent.php">Upcoming Events </a></li>
												<li><a href="const.php">Host hotels for events</a></li>
												<li><a href="const.php">Register for events</a></li>
												<li><a href="const.php">Sanction an event</a></li>
												<li><a href="const.php">Ages & Weight Classses</a></li>
											</ul>
										</li> 
                        <li><a href="const.php">K-8 YOUTH DUAL SERIES</a></li>
                        <li class="dropdown"><a href="" class="dropbtn">Sponsors</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="const.php">Sponsors </a></li>
												<li><a href="const.php">Fund Raising</a></li>
											</ul>
										</li> 
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
     <div class="row" style="width:90%; height:600px; margin-left:5%; background-color:black;">
                <div class="col-md-9">
    <section>
	
		<div class="row" style="background-color:white;">
			
				<h1 class="aligncenter" style="text-shadow: 2px 2px 5px black; color:red;">
Coaches Card</h1>	
           
		</div>
        <div style="width:90%; margin-left:5%;">
             <h2 style="color:white; text-align:center;"> Register Online for Coaches Card</h2>
            <br />
            <center><a href="https://www.nuwaymembership.com/CA" class="flash">Click Here</a></center>

        </div>
       
        
        
	</section>     
            
</div>
                <div class="col-md-3" style="margin-left:0%; height:600px; border:1px solid #C0C0C0;">
        <br />
                    <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/facebook.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Facebook</b></a></div>
                            </div>
                             <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/twitter.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Twitter</b></a></div>
                            </div>
                             <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/instagram.jpg" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Instagram</b></a></div>
                            </div>
                            <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/youtube.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Youtube</b></a></div>
                            </div>
         
         
         </div>
        
        
        </div>

	<footer>
	
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; San Diego Wrestling official Website All right reserved. Developed By </span><a href="http://webthemez.com" target="_blank">JeffOnPoint Digital Solutions</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/Gallery/jquery.quicksand.js"></script>
<script src="js/Gallery/setting.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>