<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SCWAY</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/font-awesome.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<style>
    body{
         background-color:black;
    }
.dropbtn {
    background-color:;
    color: #222;
    padding: 16px;
    font-size: 16px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 250px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color:;}
    
  .flash {
  background-color: #004A7F;
  -webkit-border-radius: 10px;
  border-radius: 0px;
  border: none;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Arial;
  font-size: 14px;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;
}
@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
</head>
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" style="margin-top:-25%; height:600%; width:100%;" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li> 
						<li><a href="about.php">About Us</a></li>
                        <li class="dropdown"><a href="" class="dropbtn">Membership</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="atcard.php">Buy an Athlete Card</a></li>
												<li><a href="clubmem.php">Club Membership</a></li>
												<li><a href="const.php">Club locator</a></li>
												<li><a href="const.php">Join a Dual Team as a Free Agent</a></li>
												<li><a href="coachcard.php">Coaches Card</a></li>
												<li><a href="const.php">Officials</a></li>
												<li><a href="vid.php">Video Tutorials</a></li>
											</ul>
										</li> 
                        <li class="dropdown active"><a href="" class="dropbtn">Events</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="upevent.php">Upcoming Events </a></li>
												<li><a href="const.php">Host hotels for events</a></li>
												<li><a href="const.php">Register for events</a></li>
												<li><a href="const.php">Sanction an event</a></li>
												<li><a href="const.php">Ages & Weight Classses</a></li>
											</ul>
										</li> 
                        <li><a href="const.php">K-8 YOUTH DUAL SERIES</a></li>
                        <li class="dropdown"><a href="" class="dropbtn">Sponsors</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="const.php">Sponsors </a></li>
												<li><a href="const.php">Fund Raising</a></li>
											</ul>
										</li> 
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
     <div class="row" style="width:90%; margin-left:5%;  background-color:black;">
                <div class="col-md-9">

    <section>
	
		<div class="row" style="background-color:white;">
			
				<h1 class="aligncenter" style="text-shadow: 2px 2px 5px black; color:red;"> RB Bronco Brawl 2018 </h1>	
           
		</div>
       <img src="img/slides/8.jpg" class="img img-thumbnail" style="width:90%; height:300px; margin-left:5%;" /><br />
                <div style="width:90%; margin-left:5%;"><br /><p style="color:white; text-align:justify;"><b>PRE-REGISTRATION</b> Is meant to help the tourney directors expedite bracketing and prepare for the upcoming event to provide a quality atmosphere and therefore the tourney directors offer a discount online up until the last day to
go online and register. We hope this encourages you to help us by registering in advance to better serve the community.
Walk up pricing on the day of the events will be significantly higher and may or may not be available  at each event so please take the few minutes and register online to help all of us.</p>
         <br />
        <h4 style="color:white;"><b><u>Cut off date:</u></b></h4></div> 
        <div style="width:90%; margin-left:5%;"><p style="color:white; text-align:justify;">Friday, December 14th, 2018 is the last day to Register </p></div>
            <br />
        <h2 style="color:white; text-align:center;"> To register for this event</h2>
            <center><a href="http://www.trackwrestling.com/registration/BasicPreReg1.jsp?tournamentGroupId=66249132" class="flash">Click Here</a></center><br />
        
        <hr style="height:1px; background-color:#C0C0C0;"  />
        <div style="width:90%; margin-left:5%;">
        <h2 style="color:white; text-align:center;">Tournament Information</h2>
        <br />
            
            
        <h3 style="color:white;"><b><u>When?</u></b></h3>
            <p style="color:white; text-align:justify;">Saturday, December 15th, 2018</p>
        <br />
            
            
        <h3 style="color:white;"><b><u>Where?</u></b></h3>
        <p style="color:white; text-align:justify;">Rancho Bernardo High School, 
13010 Paseo Lucido  San Diego Ca 92128</p>
            <br />
        
             <h3 style="color:white;"><b><u>SCWAY Competition Cards</u></b></h3>
        <p style="color:white; text-align:justify;">Competitors must show a current SCWAY competition card prior to weigh-ins in order to compete.<br />If you do not have a card yet please click on the membership tab on our website www.sandiegowrestler.com</p>
       <br /> 
            
        <h3 style="color:white;"><b><u>Divisions</u></b></h3>
        <p style="color:white; text-align:justify;">6U, 8U, 10U, 12U, 15U </p>
        <p style="color:white; text-align:justify;"><b>Madison Block Style Brackets</b> - Will be applied when necessary to create larger brackets for more quality matches tourney director then creates matchups within safe margins of age and weight. The objective is to provide as many quality matches as possible in a short period of time.</p>  <br />
            
            
        <h3 style="color:white;"><b><u>Weights</u></b></h3>
          <p style="color:white; text-align:justify;">Age and Weights</p>

            <p style="color:white; text-align:justify;">6u 38,42,46,50,56 and 66</p>
            <p style="color:white; text-align:justify;">8u 45,48,51,54,58,63,68,74,84 and 104</p>
            <p style="color:white; text-align:justify;">10u 53,57,61,64,67,70,75,80,85,97,109 and 128</p>
            <p style="color:white; text-align:justify;">12u 65,69,73,77,81,86,90,97,105,114,125 and 140</p>
            <p style="color:white; text-align:justify;">15U 75,80,85,90,95,100,106,112,118,126,134,142,153,167,185,215 and 265</p><br />
        <h3 style="color:white;"><b><u>Weigh in options</u></b></h3> 
            <p style="color:white; text-align:justify;">Saturday December 15th 6:30-8AM</p>
            
            <br />
            <p style="color:white; text-align:justify;">Tourney Director- Joe Terballinni - 619-895-2880</p> 
           
        <br /><br />
        </div></div>

	</section>     

               <div class="col-md-3" style="margin-left:0%; border:1px solid #C0C0C0;">
         <div class="panel-heading flash" style="background-color:#ff0000; border:2px solid #C0C0C0; color:white; width:100%;"><p style="text-align:center; text-shadow: 2px 2px 5px black;"><b>2018-2019 San Diego/Imperial Valley SCWAY Tournament Schedule</b></p>
                    <p style="text-align:center;">**To Register, Click on Event**</p></div>
                    <div class="panel-body"  style="background-color:black; border:2px solid #C0C0C0; width:100%;">
                        <table class="table" style="width:90%; font-size:11px; margin-left:-5%; color:white;">
                            <tr>
                                <th colspan="3" style="text-align:center;">Winter Schedule</th>
                            </tr>
                           <tr>
                               <th>Event</th>
                               <th>Date</th>
                               <th>Venue</th>
                            </tr>
                            
                            <tr>
                                <td><a href="#" style="color:white;">So Cal KickOff <b style="color:red;">(Completed)</b></a></td>
                                <td><a href="#" style="color:white;">12/02/2018</a></td>
                                <td><a href="#" style="color:white;">Villa Park High School 18042 Taft Ave.</a></td>
                            </tr>
                            <tr>
                                <td><a href="pirate.php" style="color:white;">Longhorn Roundup </a></td>
                                <td><a href="pirate.php" style="color:white;">12/09/2018</a></td>
                                <td><a href="pirate.php" style="color:white;">Rancho Buena Vista High School</a></td>
                            </tr>
                               <tr>
                                  <td><a href="rbbronco.php" style="color:white;">RB Bronco Brawl 2018</a></td>
                                <td><a href="rbbronco.php" style="color:white;">12/15/2018</a></td>
                                <td><a href="rbbronco.php" style="color:white;">Rancho Bernardo High School</a></td>
                            </tr>
                              <tr>
                                <td><a href="const.php" style="color:white;">San Diego SCWAY Duals for Glory</a></td>
                                <td><a href="const.php" style="color:white;">12/22/2018</a></td>
                                <td><a href="const.php" style="color:white;">TBD</a></td>
                            </tr>
                            <tr>
                                <td><a href="holidayduals.php" style="color:white;">Proving Grounds Kings of California 5VS5 Duals</a></td>
                                <td><a href="holidayduals.php" style="color:white;">12/29/2018</a></td>
                                <td><a href="holidayduals.php" style="color:white;">Orange County CA</a></td>
                            </tr>
                             <tr>
                                <td><a href="const.php" style="color:white;">So Cal Winter Classic</a></td>
                                <td><a href="const.php" style="color:white;">01/06/2019</a></td>
                                <td><a href="const.php" style="color:white;">San Clemete (SCWAY State Points)</a></td>
                            </tr>
                             <tr>
                                <td><a href="matrat.php" style="color:white;">Mat Rats Mayhem</a></td>
                                <td><a href="matrat.php" style="color:white;">01/20/2019</a></td>
                                <td><a href="matrat.php" style="color:white;">La Costa Canyon High School</a></td>
                            </tr>
                             <tr>
                                <td><a href="const.php" style="color:white;">SoCal Kids Open</a></td>
                                <td><a href="const.php" style="color:white;">01/27/2019</a></td>
                                <td><a href="const.php" style="color:white;">Villa Park, CA (SCWAY State Points)</a></td>
                            </tr>
                            <tr>
                                <td><a href="grind.php" style="color:white;"> Gridiron Grind II </a></td>
                                <td><a href="grind.php" style="color:white;">02/02/2019</a></td>
                                <td><a href="grind.php" style="color:white;">Army/Navy Academy (SCWAY State Points)</a></td>
                            </tr>

                            <tr>
                                <th colspan="3" style="text-align:center;">Post- Season</th>
                            </tr>
                            <tr>
                               <th>Event</th>
                               <th>Date</th>
                               <th>State</th>
                            </tr>
                            <tr>
                                <td><a href="fbrawl.php" style="color:white;">SCWAY STATE QUALIFIER (Top 5 Qualify) SCWAY State Points Event</a></td>
                                <td><a href="fbrawl.php" style="color:white;">02/10/2019</a></td>
                                <td><a href="fbrawl.php" style="color:white;">Sage Creek High School</a></td>
                            </tr>
                            
                            <tr>
                                <td><a href="const.php" style="color:white;">California High School State Finals</a></td>
                                <td><a href="const.php" style="color:white;">02/23/2019</a></td>
                                <td><a href="const.php" style="color:white;">Rabobank Arena</a></td>
                            </tr>
                            <tr>
                                <td><a href="const.php" style="color:white;">SCWAY State Championship</a></td>
                                <td><a href="const.php" style="color:white;">03/16/2019</a></td>
                                <td><a href="const.php" style="color:white;">Buchanan High School</a></td>
                            </tr>

                        </table>
                        
                    </div>
                    <div class="panel-footer" style="background-color:#ff0000; border:2px solid #C0C0C0; width:100%; color:white; text-shadow: 2px 2px 5px black;"><p style="text-align:center;">TOURNAMENTS WILL BE HELD ON SATURDAY OR SUNDAY #SDSCWAYSATURDAY</p></div>
                    <br />
                    <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/facebook.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="https://www.facebook.com/sandiegowrestler/" style="color:white;"><b>Follow us on Facebook</b></a></div>
                            </div>
                             <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/twitter.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Twitter</b></a></div>
                            </div>
                             <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/instagram.jpg" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="https://www.instagram.com/sd_wrestler/" style="color:white;"><b>Follow us on Instagram</b></a></div>
                            </div>
                            <div class="row" style="width:100%; margin-left:5%;">
                                <div class="col-md-4"><img src="img/youtube.png" style="width:40px; height:40px;" /></div>
                                <div class="col-md-8"> <a href="" style="color:white;"><b>Follow us on Youtube</b></a></div>
                            </div>
         
         
         </div>
        
        
        </div>

	<footer>
	
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; San Diego Wrestling official Website All right reserved. Developed By </span><a href="http://webthemez.com" target="_blank">JeffOnPoint Digital Solutions</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/Gallery/jquery.quicksand.js"></script>
<script src="js/Gallery/setting.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>