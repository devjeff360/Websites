<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SCWAY</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/font-awesome.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<style>
    body{
         background-color:black;
    }
.dropbtn {
    background-color:;
    color: #222;
    padding: 16px;
    font-size: 16px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 250px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color:;}
    
  .flash {
  background-color: #004A7F;
  -webkit-border-radius: 10px;
  border-radius: 0px;
  border: none;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Arial;
  font-size: 14px;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;
}
@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
</head>
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" style="margin-top:-25%; height:600%; width:100%;" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li> 
						<li><a href="about.php">About Us</a></li>
                        <li class="dropdown active"><a href="" class="dropbtn">Membership</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="atcard.php">Buy an Athlete Card</a></li>
												<li><a href="clubmem.php">Club Membership</a></li>
												<li><a href="const.php">Club locator</a></li>
												<li><a href="const.php">Join a Dual Team as a Free Agent</a></li>
												<li><a href="coachcard.php">Coaches Card</a></li>
												<li><a href="const.php">Officials</a></li>
												<li><a href="vid.php">Video Tutorials</a></li>
											</ul>
										</li> 
                        <li class="dropdown"><a href="" class="dropbtn">Events</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="upevent.php">Upcoming Events </a></li>
												<li><a href="const.php">Host hotels for events</a></li>
												<li><a href="const.php">Register for events</a></li>
												<li><a href="const.php">Sanction an event</a></li>
												<li><a href="const.php">Ages & Weight Classses</a></li>
											</ul>
										</li> 
                        <li><a href="const.php">K-8 YOUTH DUAL SERIES</a></li>
                        <li class="dropdown"><a href="" class="dropbtn">Sponsors</a>
											<ul class="dropdown-content" style="list-style-type: none;">
												<li><a href="const.php">Sponsors </a></li>
												<li><a href="const.php">Fund Raising</a></li>
											</ul>
										</li> 
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
     <div class="row" style="width:90%; margin-left:5%; background-color:black;">
                <div class="col-md-9">
    <section>
	
		<div class="row" style="background-color:white;">
			
				<h1 class="aligncenter" style="text-shadow: 2px 2px 5px black; color:red;">
Online Membership Sign-Up Directions</h1>	
           
		</div>
        <div style="width:90%; margin-left:5%; color:white;">
            <h3 style="color:white;"><b>Online Registration Process</b></h3>
<p style="color:white;">We have created videos to walk you through the process of using the MYWA online system. </p>
            <br /><br />
            <p><b><u>Creating a MYWA/NUWAY Account Video</u></b></p>

            <ul>
                <li>If you are a previous member contact Denise for login information or to be linked to your wrestlers account.</li>
                <li>Use this link https://www.nuwaymembership.com/MI to get to the MYWA online system.</li>
                <li>Click the register here button to get started.  Make sure to fill in all the fields with *.</li>
                <li>The system will automatically default to your home state.</li>
               
            </ul>
            <br /><br />
            <p><b><u>Creating a New Club Video</u></b></p>
            <ul>
                <li>If you are a club admin and need to start a NEW club with MYWA click the register New Club link on the left.</li>
                <li>Fill in all the fields, select a zone, region, area, etc.</li>
                <li>If you don't know your Region click the MYWA MAP here.</li>
                <li>NUWAY will receive an email to approve your club.  Once that is done you will be able to login and pay your membership fees.</li>
              
            </ul>
             <br /><br />
            <p><b><u>Paying Club Fees Video</u></b></p>
            <ul>
                <li>Administrators please note your club fees MUST be paid first so your club members can get the $17 membership rate.</li>
                <li>In your profile under the left menu links click on My Club</li>
                <li>There will be a button on the right hand side to "Pay Club Invoice" click that and the club fee will be added to your shopping cart.</li>
            </ul>
             <br /><br />
            <p><b><u>Paying Wrestler Fees Video</u></b></p>
            <ul>
                <li>To Renew a previous member
                    <ul>
                        <li>click on the My Club link if you are a club admin then click on the link to club wrestlers.</li>
                <li>Anyone you wish to renew just click their shopping cart under actions to add them to your cart.</li>
                <li>If you are a parent linked to your wrestler click on My Wrestlers in the left menu and add your wrestlers to your cart by clicking the shopping cart under actions.</li>
                    </ul></li>
                
                 <li>To Add new members
                    <ul>
                        <li>click on the My Wrestlers link and follow the 4 step process to add to the system (be sure to select your club when filling in the wrestlers information)</li>
                <li>When you are done it will automatically add them to your shopping cart</li>
                <li>If you are a parent linked to your wrestler click on My Wrestlers in the left menu and add your wrestlers to your cart by clicking the shopping cart under actions.</li>
                     </ul></li>
                <li>To Transfer a wrestler to your team that is a previous MYWA member contact Denise. Once she has transferred them over you will treat them like a renew wrestler.</li>
              
            </ul>
            
            <br /><br />
            <p><b><u>Printing Membership Cards Video</u></b></p>
            <ul>
                <li>MYWA membership must be paid in order to print a Membership Card.</li>
                <li>Fill in all the fields, select a zone, region, area, etc.</li>
                <li>Club admins can print each wrestlers card separately or the whole teams in the My Club tab under Club Wrestlers.</li>
                <li>Parents if linked to their wrestler can print cards by clicking the photo icon under actions.</li>
              
            </ul>
            <br /><br />
            <p><b><u>Registering for Tournaments Video</u></b></p>
            <ul>
                <li>When logged into the MYWA system you will see a link at the top for tournaments you can click that to get to all the MYWA events.</li>
                <li>If you would like to do a out of State NUWAY event you can change the State and click GO to see events in other states.</li>
                <li>To register you will click the Red "i" (Info) under actions for the event you want to attend. Please note there will be separate events listed for Open and Novice Divisions.</li>
                <li>In the new screen click Register Now.</li>
                <li>Under actions next to the wrestler you want to register click the edit pencil.</li>
                <li>Select the correct Age Group and put 0 for actual weight then click submit.</li>
                <li>If there is online payment for the event a shopping cart will appear under actions for you to add the wrestlers to the cart to pay their event fees.</li>
              
            </ul>
            <br /><br />
            <p><b><u>Insurance Binder Request Video for Club Administrators</u></b></p>
            <ul>
                <li>If your school/practice facility needs proof of insurance this can now be done online through your Admin account once your club fee is paid.</li>
                <li>In your profile on the left menu there is a link to request insurance binder.</li>
                <li>Click the + to Add the practice site(s) for your club.</li>
                <li>Fill in all the fields and click submit.</li>
                <li>Click the Send Request button
                    <ul>
                        <li>an email will be sent to our MYWA administrator & our insurance provider</li>
                        <li>the binder will be emailed back to our MYWA administrator who will then forward it on to you.</li>
                        <li>This process usually take 24 hours unless it is requested over the weekend.</li>
                    </ul>
                
                </li>

            </ul>
            <br /><br />


        </div>
       
        
        
	</section>     
            
</div>
                <div class="col-md-3" style="margin-left:0%; border:1px solid #C0C0C0;">
         <br /><br /><br /><br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/YU9XXjVueZI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/dQuJUN2KYfk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/qwnPMJJLATs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/jnt9vQz0G9U" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/SnBFL_LKlhI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/TvEHpJHFu5c" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    <br />
            <iframe width="249" height="211" src="https://www.youtube.com/embed/z9YiR1CkoXo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
         
         
         </div>
        
        
        </div>

	<footer>
	
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; San Diego Wrestling official Website All right reserved. Developed By </span><a href="http://webthemez.com" target="_blank">JeffOnPoint Digital Solutions</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/Gallery/jquery.quicksand.js"></script>
<script src="js/Gallery/setting.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>